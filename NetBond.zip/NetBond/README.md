# NetBond — Smart Network Load Balancer for Android

NetBond routes your app's traffic intelligently across **Wi-Fi and Mobile Data simultaneously**, using Android's native `ConnectivityManager.bindProcessToNetwork()` API — no root, no VPN, no server required.

---

## How It Works

Android allows apps to explicitly choose which network a socket uses. NetBond:

1. **Monitors** both Wi-Fi and Cellular in real time (signal, speed, availability)
2. **Scores** each interface using signal strength + measured throughput
3. **Selects** the best interface per request using the chosen strategy
4. **Binds** the process to that network via `ConnectivityManager.bindProcessToNetwork()`

All traffic from the NetBond process is routed through whichever interface the engine selects.

---

## Routing Strategies

| Strategy | How It Works |
|---|---|
| **Best Signal** | Always uses the highest-scoring interface; switches only on failure |
| **Round Robin** | Alternates requests between Wi-Fi and Mobile equally |
| **Smart Split** | Large transfers (≥1 MB) go to fastest; small requests split evenly |
| **Wi-Fi Priority** | Uses Wi-Fi unless signal drops below 25%; then falls back to Mobile |

---

## Project Structure

```
NetBond/
├── app/src/main/
│   ├── java/com/netbond/
│   │   ├── model/
│   │   │   ├── NetworkInterface.java      # Interface state + scoring
│   │   │   └── LoadBalancerStrategy.java  # Strategy enum
│   │   ├── utils/
│   │   │   ├── NetworkMonitor.java        # Real-time speed & signal measurement
│   │   │   └── LoadBalancerEngine.java    # Core routing decision logic
│   │   ├── service/
│   │   │   └── LoadBalancerService.java   # Foreground service (keeps running)
│   │   └── ui/
│   │       └── MainActivity.java          # UI + BroadcastReceiver for live updates
│   ├── res/
│   │   ├── layout/activity_main.xml       # Dark-themed dashboard UI
│   │   ├── values/{colors, strings, themes}.xml
│   │   └── drawable/                      # Icons + spinner background
│   └── AndroidManifest.xml
└── build.gradle (root + app)
```

---

## Build Instructions

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 11+
- Android SDK with API 34

### Steps

1. **Clone / unzip** this project
2. Open in **Android Studio → File → Open**
3. Let Gradle sync finish
4. Connect a physical device (API 26+) — emulators don't have real dual networks
5. **Run** (`Shift+F10`) or build APK via `Build → Build APK`

### Permissions Required
- `ACCESS_NETWORK_STATE` / `ACCESS_WIFI_STATE` — read network info
- `CHANGE_NETWORK_STATE` — bind process to specific network
- `FOREGROUND_SERVICE` — keep service alive in background
- `READ_PHONE_STATE` — read cellular signal info
- `POST_NOTIFICATIONS` (Android 13+) — show persistent notification

---

## Usage

1. Launch **NetBond**
2. Select your preferred **Routing Strategy** from the dropdown
3. Tap **Start Load Balancer**
4. The dashboard shows live signal, speed, and which interface is currently active
5. The service persists in the background with a notification — tap it to return to the app
6. Tap **Stop Load Balancer** to disable routing and restore default behaviour

---

## Important Notes

- **Both interfaces must be active**: On most Android devices, when Wi-Fi is connected, mobile data is suspended. Go to **Settings → Network → Mobile Data** and enable *"Use mobile data always"* or your carrier's equivalent to keep both active simultaneously.
- **Data usage**: With both interfaces active, your mobile data quota will be consumed. Monitor usage in system settings.
- **Battery**: Running two radios increases battery drain slightly.
- **True bonding**: This app load-balances (picks one interface per request), it does not *bond* (split one download across both). True bonding requires a relay server (e.g. Speedify).

---

## Dependencies

```gradle
implementation 'androidx.appcompat:appcompat:1.6.1'
implementation 'com.google.android.material:material:1.11.0'
implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
```

All standard AndroidX — no external services, no accounts, no analytics.
