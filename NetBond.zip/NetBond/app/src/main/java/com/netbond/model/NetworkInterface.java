package com.netbond.model;

public class NetworkInterface {
    public enum Type { WIFI, CELLULAR }

    private final Type type;
    private boolean available;
    private boolean active;
    private float signalStrength;  // 0.0 - 1.0
    private long downloadSpeed;    // bytes/sec (measured)
    private long uploadSpeed;      // bytes/sec (measured)
    private long totalBytesRouted;
    private int priority;          // 1 = highest

    public NetworkInterface(Type type) {
        this.type = type;
        this.available = false;
        this.active = false;
        this.signalStrength = 0f;
        this.downloadSpeed = 0L;
        this.uploadSpeed = 0L;
        this.totalBytesRouted = 0L;
        this.priority = (type == Type.WIFI) ? 1 : 2;
    }

    public Type getType() { return type; }
    public String getName() { return type == Type.WIFI ? "Wi-Fi" : "Mobile Data"; }

    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    public float getSignalStrength() { return signalStrength; }
    public void setSignalStrength(float signalStrength) { this.signalStrength = signalStrength; }

    public long getDownloadSpeed() { return downloadSpeed; }
    public void setDownloadSpeed(long downloadSpeed) { this.downloadSpeed = downloadSpeed; }

    public long getUploadSpeed() { return uploadSpeed; }
    public void setUploadSpeed(long uploadSpeed) { this.uploadSpeed = uploadSpeed; }

    public long getTotalBytesRouted() { return totalBytesRouted; }
    public void addBytesRouted(long bytes) { this.totalBytesRouted += bytes; }

    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }

    /** Combined score used by load-balancer (higher = prefer this interface) */
    public float getScore() {
        if (!available || !active) return 0f;
        float speedScore = Math.min(downloadSpeed / 10_000_000f, 1.0f); // normalise to 10 Mbps
        return (signalStrength * 0.4f) + (speedScore * 0.6f);
    }
}
