package com.netbond.ui;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.service.quicksettings.TileService;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.netbond.R;
import com.netbond.databinding.ActivityMainBinding;
import com.netbond.model.LoadBalancerStrategy;
import com.netbond.service.LoadBalancerService;
import com.netbond.service.NetBondTileService;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME   = "netbond_prefs";
    private static final String KEY_RUNNING  = "service_running";
    private static final String KEY_STRATEGY = "selected_strategy";

    private ActivityMainBinding binding;
    private SharedPreferences prefs;
    private boolean serviceRunning = false;

    private final BroadcastReceiver updateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            if (LoadBalancerService.BROADCAST_UPDATE.equals(intent.getAction())) {
                updateUI(intent);
            }
        }
    };

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        requestPermissionsIfNeeded();
        setupStrategySpinner();
        setupToggleButton();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Restore running state in case service was started/stopped from the tile
        serviceRunning = prefs.getBoolean(KEY_RUNNING, false);
        refreshToggleButtonUI();

        IntentFilter filter = new IntentFilter(LoadBalancerService.BROADCAST_UPDATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(updateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(updateReceiver, filter);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(updateReceiver);
        } catch (IllegalArgumentException ignored) { /* not registered */ }
    }

    // ─── UI setup ─────────────────────────────────────────────────────────────

    private void setupStrategySpinner() {
        LoadBalancerStrategy[] strategies = LoadBalancerStrategy.values();
        List<String> names = new ArrayList<>(strategies.length);
        for (LoadBalancerStrategy s : strategies) names.add(s.getDisplayName());

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, names);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerStrategy.setAdapter(adapter);

        // Restore previously chosen strategy
        String savedName = prefs.getString(KEY_STRATEGY, LoadBalancerStrategy.SMART_SPLIT.name());
        for (int i = 0; i < strategies.length; i++) {
            if (strategies[i].name().equals(savedName)) {
                binding.spinnerStrategy.setSelection(i, false);
                binding.tvStrategyDesc.setText(strategies[i].getDescription());
                break;
            }
        }

        binding.spinnerStrategy.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                LoadBalancerStrategy selected = strategies[pos];
                binding.tvStrategyDesc.setText(selected.getDescription());
                prefs.edit().putString(KEY_STRATEGY, selected.name()).apply();
                if (serviceRunning) sendStrategyToService(selected);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupToggleButton() {
        binding.btnToggle.setOnClickListener(v -> {
            if (serviceRunning) {
                doStopService();
            } else {
                doStartService();
            }
        });
    }

    // ─── Service control ──────────────────────────────────────────────────────

    private void doStartService() {
        Intent intent = new Intent(this, LoadBalancerService.class);
        intent.setAction(LoadBalancerService.ACTION_START);
        startForegroundService(intent);

        serviceRunning = true;
        prefs.edit().putBoolean(KEY_RUNNING, true).apply();

        // Push selected strategy immediately
        int pos = binding.spinnerStrategy.getSelectedItemPosition();
        if (pos >= 0) sendStrategyToService(LoadBalancerStrategy.values()[pos]);

        // Notify tile to re-query its state
        requestTileUpdate();

        refreshToggleButtonUI();
        binding.tvReason.setText("Detecting networks…");
    }

    private void doStopService() {
        Intent intent = new Intent(this, LoadBalancerService.class);
        intent.setAction(LoadBalancerService.ACTION_STOP);
        startService(intent);

        serviceRunning = false;
        prefs.edit().putBoolean(KEY_RUNNING, false).apply();

        requestTileUpdate();
        refreshToggleButtonUI();
        binding.tvReason.setText("—");
        binding.tvActiveIface.setText("Routing via: —");
    }

    private void sendStrategyToService(LoadBalancerStrategy strategy) {
        Intent intent = new Intent(this, LoadBalancerService.class);
        intent.setAction(LoadBalancerService.ACTION_STRATEGY);
        intent.putExtra(LoadBalancerService.EXTRA_STRATEGY, strategy.name());
        startService(intent);
    }

    /** Ask the Quick Settings tile to re-read SharedPreferences and refresh. */
    private void requestTileUpdate() {
        TileService.requestListeningState(this,
                new ComponentName(this, NetBondTileService.class));
    }

    // ─── UI updates ───────────────────────────────────────────────────────────

    /** Syncs button text/colour and status label to match serviceRunning. */
    private void refreshToggleButtonUI() {
        if (serviceRunning) {
            binding.btnToggle.setText("Stop Load Balancer");
            binding.btnToggle.setBackgroundTintList(getColorStateList(R.color.stop_button));
            binding.tvStatus.setText("Active");
            binding.tvStatus.setTextColor(getColor(R.color.status_active));
        } else {
            binding.btnToggle.setText("Start Load Balancer");
            binding.btnToggle.setBackgroundTintList(getColorStateList(R.color.start_button));
            binding.tvStatus.setText("Inactive");
            binding.tvStatus.setTextColor(getColor(R.color.status_inactive));
        }
    }

    private void updateUI(Intent data) {
        boolean wifiAvail  = data.getBooleanExtra(LoadBalancerService.EXTRA_WIFI_AVAIL,  false);
        boolean wifiActive = data.getBooleanExtra(LoadBalancerService.EXTRA_WIFI_ACTIVE, false);
        float   wifiSignal = data.getFloatExtra(  LoadBalancerService.EXTRA_WIFI_SIGNAL, 0f);
        long    wifiDl     = data.getLongExtra(   LoadBalancerService.EXTRA_WIFI_DL,     0L);
        boolean cellAvail  = data.getBooleanExtra(LoadBalancerService.EXTRA_CELL_AVAIL,  false);
        boolean cellActive = data.getBooleanExtra(LoadBalancerService.EXTRA_CELL_ACTIVE, false);
        float   cellSignal = data.getFloatExtra(  LoadBalancerService.EXTRA_CELL_SIGNAL, 0f);
        long    cellDl     = data.getLongExtra(   LoadBalancerService.EXTRA_CELL_DL,     0L);
        String  activeIface = data.getStringExtra(LoadBalancerService.EXTRA_ACTIVE_IFACE);
        String  reason      = data.getStringExtra(LoadBalancerService.EXTRA_REASON);

        // Wi-Fi card
        binding.tvWifiStatus.setText(wifiActive ? "Connected" : (wifiAvail ? "Available" : "Unavailable"));
        binding.tvWifiStatus.setTextColor(getColor(wifiActive ? R.color.status_active : R.color.status_inactive));
        binding.progressWifiSignal.setProgress((int) (wifiSignal * 100));
        binding.tvWifiSignal.setText(String.format("%.0f%%", wifiSignal * 100));
        binding.tvWifiSpeed.setText(formatSpeed(wifiDl));

        // Cellular card
        binding.tvCellStatus.setText(cellActive ? "Connected" : (cellAvail ? "Available" : "Unavailable"));
        binding.tvCellStatus.setTextColor(getColor(cellActive ? R.color.status_active : R.color.status_inactive));
        binding.progressCellSignal.setProgress((int) (cellSignal * 100));
        binding.tvCellSignal.setText(String.format("%.0f%%", cellSignal * 100));
        binding.tvCellSpeed.setText(formatSpeed(cellDl));

        // Active routing
        if (activeIface != null && !activeIface.isEmpty()) {
            binding.tvActiveIface.setText("Routing via: " + activeIface);
        }
        if (reason != null && !reason.isEmpty()) {
            binding.tvReason.setText(reason);
        }
    }

    private String formatSpeed(long bytesPerSec) {
        if (bytesPerSec <= 0)         return "—";
        if (bytesPerSec < 1_024L)     return bytesPerSec + " B/s";
        if (bytesPerSec < 1_048_576L) return String.format("%.1f KB/s", bytesPerSec / 1024f);
        return                               String.format("%.1f MB/s", bytesPerSec / 1_048_576f);
    }

    // ─── Permissions ──────────────────────────────────────────────────────────

    private void requestPermissionsIfNeeded() {
        List<String> perms = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.READ_PHONE_STATE);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!perms.isEmpty()) {
            ActivityCompat.requestPermissions(this, perms.toArray(new String[0]), 100);
        }
    }
}
