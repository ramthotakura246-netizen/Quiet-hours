package com.netbond.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;

import com.netbond.model.LoadBalancerStrategy;
import com.netbond.model.NetworkInterface;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Selects the optimal Network per request and binds the process to it.
 *
 * Network discovery is event-driven via ConnectivityManager.NetworkCallback —
 * no polling, no redundant IPC calls per monitor tick.
 *
 * All mutable Network references are held in AtomicReferences for safe
 * cross-thread access (monitor thread writes, main thread may read).
 */
public class LoadBalancerEngine {

    public interface DecisionListener {
        void onDecision(String interfaceName, String reason);
    }

    private final ConnectivityManager cm;
    private volatile LoadBalancerStrategy strategy = LoadBalancerStrategy.SMART_SPLIT;

    // AtomicReference for thread-safe access across monitor and main threads
    private final AtomicReference<Network> wifiNetwork = new AtomicReference<>(null);
    private final AtomicReference<Network> cellNetwork = new AtomicReference<>(null);

    private volatile NetworkInterface wifiIface;
    private volatile NetworkInterface cellIface;

    private final AtomicInteger roundRobinCounter = new AtomicInteger(0);
    private volatile DecisionListener decisionListener;

    private static final float WIFI_FALLBACK_THRESHOLD = 0.25f;
    private static final long  LARGE_REQUEST_BYTES     = 1_000_000L; // 1 MB

    // ─── NetworkCallback — replaces polling discoverNetworks() ───────────────

    private final ConnectivityManager.NetworkCallback networkCallback =
            new ConnectivityManager.NetworkCallback() {

        @Override
        public void onAvailable(Network network) {
            classifyAndStore(network);
        }

        @Override
        public void onLost(Network network) {
            // Clear whichever slot this network occupied
            wifiNetwork.compareAndSet(network, null);
            cellNetwork.compareAndSet(network, null);
        }

        @Override
        public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
            classifyAndStore(network, caps);
        }

        private void classifyAndStore(Network network) {
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            if (caps != null) classifyAndStore(network, caps);
        }

        private void classifyAndStore(Network network, NetworkCapabilities caps) {
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                wifiNetwork.set(network);
            } else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                cellNetwork.set(network);
            }
        }
    };

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    public LoadBalancerEngine(Context context) {
        this.cm = (ConnectivityManager) context.getApplicationContext()
                .getSystemService(Context.CONNECTIVITY_SERVICE);

        // Listen for ALL networks (WiFi + Cellular)
        NetworkRequest request = new NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build();
        cm.registerNetworkCallback(request, networkCallback);
    }

    public void release() {
        try {
            cm.unregisterNetworkCallback(networkCallback);
        } catch (IllegalArgumentException ignored) { /* already unregistered */ }
        cm.bindProcessToNetwork(null);
    }

    // ─── Public API ───────────────────────────────────────────────────────────

    public void setDecisionListener(DecisionListener l) { this.decisionListener = l; }

    public void setStrategy(LoadBalancerStrategy strategy) {
        this.strategy = strategy;
        applyStrategy(0);
    }

    public LoadBalancerStrategy getStrategy() { return strategy; }

    /** Called by NetworkMonitor on each 1-second tick with fresh interface data. */
    public void onNetworkUpdated(NetworkInterface wifi, NetworkInterface cellular) {
        this.wifiIface = wifi;
        this.cellIface = cellular;
        applyStrategy(0);
    }

    /** Explicitly choose network for a known request size (0 = unknown/small). */
    public Network chooseNetwork(long requestSizeBytes) {
        return applyStrategy(requestSizeBytes);
    }

    // ─── Strategy engine ─────────────────────────────────────────────────────

    private Network applyStrategy(long requestSizeBytes) {
        Network wNet = wifiNetwork.get();
        Network cNet = cellNetwork.get();
        NetworkInterface wIface = wifiIface;
        NetworkInterface cIface = cellIface;

        boolean wifiOk = wNet != null && wIface != null && wIface.isActive();
        boolean cellOk = cNet != null && cIface != null && cIface.isActive();

        // Neither interface ready yet
        if (!wifiOk && !cellOk) return null;

        Network chosen;
        String  reason;

        switch (strategy) {

            case BEST_SIGNAL: {
                if (wifiOk && cellOk) {
                    boolean preferWifi = wIface.getScore() >= cIface.getScore();
                    chosen = preferWifi ? wNet : cNet;
                    reason = preferWifi
                            ? String.format("Wi-Fi score %.2f ≥ Mobile %.2f", wIface.getScore(), cIface.getScore())
                            : String.format("Mobile score %.2f > Wi-Fi %.2f", cIface.getScore(), wIface.getScore());
                } else {
                    chosen = wifiOk ? wNet : cNet;
                    reason = "Single interface active";
                }
                break;
            }

            case ROUND_ROBIN: {
                if (wifiOk && cellOk) {
                    boolean useWifi = (roundRobinCounter.getAndIncrement() & 1) == 0;
                    chosen = useWifi ? wNet : cNet;
                    reason = "Round-robin → " + (useWifi ? "Wi-Fi" : "Mobile");
                } else {
                    chosen = wifiOk ? wNet : cNet;
                    reason = "Single interface active";
                }
                break;
            }

            case SMART_SPLIT: {
                if (wifiOk && cellOk) {
                    if (requestSizeBytes >= LARGE_REQUEST_BYTES) {
                        boolean wifiFaster = wIface.getDownloadSpeed() >= cIface.getDownloadSpeed();
                        chosen = wifiFaster ? wNet : cNet;
                        reason = "Large transfer → " + (wifiFaster ? "Wi-Fi (faster)" : "Mobile (faster)");
                    } else {
                        boolean useWifi = (roundRobinCounter.getAndIncrement() & 1) == 0;
                        chosen = useWifi ? wNet : cNet;
                        reason = "Small request → balanced split";
                    }
                } else {
                    chosen = wifiOk ? wNet : cNet;
                    reason = "Single interface active";
                }
                break;
            }

            case WIFI_FIRST:
            default: {
                if (wifiOk && wIface.getSignalStrength() > WIFI_FALLBACK_THRESHOLD) {
                    chosen = wNet;
                    reason = String.format("Wi-Fi signal %.0f%% (above threshold)", wIface.getSignalStrength() * 100);
                } else if (cellOk) {
                    chosen = cNet;
                    reason = wifiOk
                            ? String.format("Wi-Fi signal %.0f%% weak → Mobile", wIface.getSignalStrength() * 100)
                            : "Wi-Fi unavailable → Mobile";
                } else {
                    chosen = wNet; // last resort: weak Wi-Fi beats nothing
                    reason = "Mobile unavailable, using weak Wi-Fi";
                }
                break;
            }
        }

        if (chosen != null) {
            cm.bindProcessToNetwork(chosen);
            DecisionListener dl = decisionListener;
            if (dl != null) {
                String iface = (chosen == wNet) ? "Wi-Fi" : "Mobile";
                dl.onDecision(iface, reason);
            }
        }

        return chosen;
    }
}
