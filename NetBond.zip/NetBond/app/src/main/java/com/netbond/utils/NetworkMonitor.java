package com.netbond.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.TrafficStats;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;

import com.netbond.model.NetworkInterface;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Polls network state every second on a single background thread.
 * Calls getAllNetworks() ONCE per cycle to avoid redundant IPC calls.
 * Uses TrafficStats device-wide deltas for throughput measurement.
 * Avoids deprecated WifiManager.getConnectionInfo() on API 31+.
 */
public class NetworkMonitor {

    public interface Listener {
        void onNetworkUpdated(NetworkInterface wifi, NetworkInterface cellular);
    }

    private final ConnectivityManager cm;
    private final WifiManager wm;

    private final NetworkInterface wifiIface = new NetworkInterface(NetworkInterface.Type.WIFI);
    private final NetworkInterface cellIface = new NetworkInterface(NetworkInterface.Type.CELLULAR);

    private Listener listener;
    private ScheduledExecutorService scheduler;

    // Throughput delta state
    private long lastRxBytes = TrafficStats.UNSUPPORTED;
    private long lastTxBytes = TrafficStats.UNSUPPORTED;
    private long lastMeasureMs = 0L;

    public NetworkMonitor(Context context) {
        this.cm = (ConnectivityManager) context.getApplicationContext()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        this.wm = (WifiManager) context.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void start() {
        lastRxBytes = TrafficStats.getTotalRxBytes();
        lastTxBytes = TrafficStats.getTotalTxBytes();
        lastMeasureMs = System.currentTimeMillis();

        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "NetBond-Monitor");
            t.setDaemon(true);
            return t;
        });
        scheduler.scheduleAtFixedRate(this::measure, 0, 1, TimeUnit.SECONDS);
    }

    public void stop() {
        if (scheduler != null) {
            scheduler.shutdownNow();
            scheduler = null;
        }
    }

    // ─── Core measurement loop ────────────────────────────────────────────────

    private void measure() {
        try {
            // Single IPC call per cycle — reuse result for both interfaces
            Network[] networks = cm.getAllNetworks();

            boolean wifiFound = false;
            boolean cellFound = false;

            for (Network net : networks) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(net);
                if (caps == null) continue;

                if (!wifiFound && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    wifiFound = true;
                    updateWifi(caps);
                } else if (!cellFound && caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                    cellFound = true;
                    updateCellular(caps);
                }

                if (wifiFound && cellFound) break; // no need to iterate further
            }

            if (!wifiFound) resetIface(wifiIface);
            if (!cellFound) resetIface(cellIface);

            measureThroughput();

            if (listener != null) {
                listener.onNetworkUpdated(wifiIface, cellIface);
            }
        } catch (Exception e) {
            // Swallow — scheduler must not stop on transient errors
        }
    }

    private void updateWifi(NetworkCapabilities caps) {
        wifiIface.setAvailable(true);
        wifiIface.setActive(
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED));

        float signal = readWifiSignal(caps);
        wifiIface.setSignalStrength(signal);

        // Seed download speed from link rate on first measure, real delta takes over after
        if (wifiIface.getDownloadSpeed() == 0) {
            long linkBps = readWifiLinkSpeedBps();
            if (linkBps > 0) wifiIface.setDownloadSpeed(linkBps);
        }
    }

    private void updateCellular(NetworkCapabilities caps) {
        cellIface.setAvailable(true);
        cellIface.setActive(
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED));

        float signal;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // getSignalStrength() returns dBm-ish value; map roughly -110..−50 → 0..1
            int dbm = caps.getSignalStrength();
            signal = Math.max(0f, Math.min(1f, (dbm + 110f) / 60f));
        } else {
            signal = 0.6f; // reasonable fallback for API 26-28
        }
        cellIface.setSignalStrength(signal);
    }

    private static void resetIface(NetworkInterface iface) {
        iface.setAvailable(false);
        iface.setActive(false);
        iface.setSignalStrength(0f);
        iface.setDownloadSpeed(0);
        iface.setUploadSpeed(0);
    }

    // ─── Signal helpers ───────────────────────────────────────────────────────

    /**
     * Read Wi-Fi signal strength.
     * API 31+: pull RSSI from NetworkCapabilities to avoid deprecated getConnectionInfo().
     * API 26-30: fall back to WifiManager.
     */
    @SuppressWarnings("deprecation")
    private float readWifiSignal(NetworkCapabilities caps) {
        int rssi;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // TransportInfo is WifiInfo when transport is WIFI
            android.net.TransportInfo ti = caps.getTransportInfo();
            if (ti instanceof WifiInfo) {
                rssi = ((WifiInfo) ti).getRssi();
            } else {
                rssi = -70; // safe fallback
            }
        } else {
            // Deprecated but only path available below API 31
            rssi = wm.getConnectionInfo().getRssi();
        }
        // WifiManager.calculateSignalLevel: 0..numLevels-1
        int bars = WifiManager.calculateSignalLevel(rssi, 5); // 0..4
        return bars / 4f;
    }

    @SuppressWarnings("deprecation")
    private long readWifiLinkSpeedBps() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return 0L; // skip; real delta measurement is more accurate
        }
        int mbps = wm.getConnectionInfo().getLinkSpeed(); // Mbps
        return mbps > 0 ? mbps * 125_000L : 0L; // Mbps → bytes/sec (÷8 * 10^6)
    }

    // ─── Throughput ───────────────────────────────────────────────────────────

    private void measureThroughput() {
        long nowRx = TrafficStats.getTotalRxBytes();
        long nowTx = TrafficStats.getTotalTxBytes();
        long nowMs  = System.currentTimeMillis();

        if (lastRxBytes == TrafficStats.UNSUPPORTED || nowRx == TrafficStats.UNSUPPORTED) {
            lastRxBytes = nowRx;
            lastTxBytes = nowTx;
            lastMeasureMs = nowMs;
            return;
        }

        long dtMs = nowMs - lastMeasureMs;
        if (dtMs < 100) return; // guard against scheduler jitter

        long rxDelta = Math.max(0, nowRx - lastRxBytes);
        long txDelta = Math.max(0, nowTx - lastTxBytes);

        // bytes/sec
        long dlBps = rxDelta * 1000L / dtMs;
        long ulBps = txDelta * 1000L / dtMs;

        // Distribute observed throughput proportionally by signal score.
        // If only one interface is active it gets 100%.
        float wSig = wifiIface.isActive()  ? wifiIface.getSignalStrength()  : 0f;
        float cSig = cellIface.isActive()  ? cellIface.getSignalStrength()  : 0f;
        float total = wSig + cSig;

        if (total > 0f) {
            wifiIface.setDownloadSpeed((long) (dlBps * wSig / total));
            wifiIface.setUploadSpeed  ((long) (ulBps * wSig / total));
            cellIface.setDownloadSpeed((long) (dlBps * cSig / total));
            cellIface.setUploadSpeed  ((long) (ulBps * cSig / total));
        } else {
            wifiIface.setDownloadSpeed(0); wifiIface.setUploadSpeed(0);
            cellIface.setDownloadSpeed(0); cellIface.setUploadSpeed(0);
        }

        lastRxBytes   = nowRx;
        lastTxBytes   = nowTx;
        lastMeasureMs = nowMs;
    }

    public NetworkInterface getWifi()     { return wifiIface; }
    public NetworkInterface getCellular() { return cellIface; }
}
