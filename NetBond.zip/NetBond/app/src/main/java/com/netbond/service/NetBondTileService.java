package com.netbond.service;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Icon;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

import com.netbond.R;

/**
 * NetBondTileService — adds a toggle tile to the Android Quick Settings panel.
 *
 * User adds it via: Pull down notification shade → Edit/pencil icon → drag "NetBond" tile in.
 * Tapping the tile starts or stops the LoadBalancerService without opening the app.
 */
public class NetBondTileService extends TileService {

    private static final String PREFS_NAME  = "netbond_prefs";
    private static final String KEY_RUNNING = "service_running";

    // ─── Tile lifecycle ───────────────────────────────────────────────────────

    /** Called when the tile becomes visible in the panel. Sync its state. */
    @Override
    public void onStartListening() {
        super.onStartListening();
        syncTile();
    }

    /** Called when the user taps the tile. */
    @Override
    public void onClick() {
        super.onClick();
        boolean running = isServiceRunning();
        if (running) {
            stopBalancer();
        } else {
            startBalancer();
        }
        syncTile();
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private void startBalancer() {
        Intent intent = new Intent(this, LoadBalancerService.class);
        intent.setAction(LoadBalancerService.ACTION_START);
        startForegroundService(intent);
        setRunning(true);
    }

    private void stopBalancer() {
        Intent intent = new Intent(this, LoadBalancerService.class);
        intent.setAction(LoadBalancerService.ACTION_STOP);
        startService(intent);
        setRunning(false);
    }

    /** Updates the tile's icon, label, and active/inactive state. */
    private void syncTile() {
        Tile tile = getQsTile();
        if (tile == null) return;

        boolean running = isServiceRunning();

        tile.setIcon(Icon.createWithResource(this, R.drawable.ic_tile_loadbalance));
        tile.setLabel("NetBond");

        if (running) {
            tile.setState(Tile.STATE_ACTIVE);
            tile.setSubtitle("Load balancer ON");
        } else {
            tile.setState(Tile.STATE_INACTIVE);
            tile.setSubtitle("Tap to enable");
        }

        tile.updateTile();
    }

    // ─── Persistent state (SharedPreferences) ─────────────────────────────────

    private boolean isServiceRunning() {
        return getPrefs().getBoolean(KEY_RUNNING, false);
    }

    private void setRunning(boolean running) {
        getPrefs().edit().putBoolean(KEY_RUNNING, running).apply();
    }

    private SharedPreferences getPrefs() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    }
}
