package com.netbond.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import com.netbond.R;
import com.netbond.model.LoadBalancerStrategy;
import com.netbond.model.NetworkInterface;
import com.netbond.ui.MainActivity;
import com.netbond.utils.LoadBalancerEngine;
import com.netbond.utils.NetworkMonitor;

public class LoadBalancerService extends Service implements NetworkMonitor.Listener {

    private static final String CHANNEL_ID = "netbond_channel";
    private static final int NOTIFICATION_ID = 1001;

    public static final String ACTION_START  = "com.netbond.START";
    public static final String ACTION_STOP   = "com.netbond.STOP";
    public static final String ACTION_STRATEGY = "com.netbond.STRATEGY";
    public static final String EXTRA_STRATEGY  = "strategy";

    // Broadcast actions for UI updates
    public static final String BROADCAST_UPDATE   = "com.netbond.UPDATE";
    public static final String EXTRA_WIFI_AVAIL   = "wifi_avail";
    public static final String EXTRA_WIFI_ACTIVE  = "wifi_active";
    public static final String EXTRA_WIFI_SIGNAL  = "wifi_signal";
    public static final String EXTRA_WIFI_DL      = "wifi_dl";
    public static final String EXTRA_CELL_AVAIL   = "cell_avail";
    public static final String EXTRA_CELL_ACTIVE  = "cell_active";
    public static final String EXTRA_CELL_SIGNAL  = "cell_signal";
    public static final String EXTRA_CELL_DL      = "cell_dl";
    public static final String EXTRA_ACTIVE_IFACE = "active_iface";
    public static final String EXTRA_REASON       = "reason";

    public class LocalBinder extends Binder {
        public LoadBalancerService getService() { return LoadBalancerService.this; }
    }

    private final IBinder binder = new LocalBinder();
    private NetworkMonitor monitor;
    private LoadBalancerEngine engine;
    private String lastActiveIface = "";
    private String lastReason = "";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        monitor = new NetworkMonitor(this);
        engine  = new LoadBalancerEngine(this);

        monitor.setListener(this);
        engine.setDecisionListener((iface, reason) -> {
            lastActiveIface = iface;
            lastReason = reason;
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;

        switch (intent.getAction() != null ? intent.getAction() : "") {
            case ACTION_START:
                startForeground(NOTIFICATION_ID, buildNotification("Running · monitoring networks"));
                monitor.start();
                break;

            case ACTION_STOP:
                monitor.stop();
                engine.release();
                stopForeground(true);
                stopSelf();
                break;

            case ACTION_STRATEGY:
                String stratName = intent.getStringExtra(EXTRA_STRATEGY);
                if (stratName != null) {
                    engine.setStrategy(LoadBalancerStrategy.valueOf(stratName));
                }
                break;
        }
        return START_STICKY;
    }

    @Override
    public void onNetworkUpdated(NetworkInterface wifi, NetworkInterface cellular) {
        engine.onNetworkUpdated(wifi, cellular);

        Intent broadcast = new Intent(BROADCAST_UPDATE);
        broadcast.putExtra(EXTRA_WIFI_AVAIL,   wifi.isAvailable());
        broadcast.putExtra(EXTRA_WIFI_ACTIVE,  wifi.isActive());
        broadcast.putExtra(EXTRA_WIFI_SIGNAL,  wifi.getSignalStrength());
        broadcast.putExtra(EXTRA_WIFI_DL,      wifi.getDownloadSpeed());
        broadcast.putExtra(EXTRA_CELL_AVAIL,   cellular.isAvailable());
        broadcast.putExtra(EXTRA_CELL_ACTIVE,  cellular.isActive());
        broadcast.putExtra(EXTRA_CELL_SIGNAL,  cellular.getSignalStrength());
        broadcast.putExtra(EXTRA_CELL_DL,      cellular.getDownloadSpeed());
        broadcast.putExtra(EXTRA_ACTIVE_IFACE, lastActiveIface);
        broadcast.putExtra(EXTRA_REASON,       lastReason);
        sendBroadcast(broadcast);

        // Update notification text
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            String text = "Active: " + (lastActiveIface.isEmpty() ? "detecting…" : lastActiveIface);
            nm.notify(NOTIFICATION_ID, buildNotification(text));
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return binder; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (monitor != null) monitor.stop();
        if (engine != null) engine.release();
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "NetBond Service", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Load balancer running in background");
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    private Notification buildNotification(String text) {
        Intent tapIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, tapIntent,
                PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("NetBond Load Balancer")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_tile_loadbalance)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }
}
