package com.netbond.model;

public enum LoadBalancerStrategy {
    /** Always use highest-scoring interface; switch only on failure */
    BEST_SIGNAL("Best Signal", "Routes all traffic through the strongest connection"),

    /** Alternate requests round-robin across both interfaces */
    ROUND_ROBIN("Round Robin", "Alternates requests across Wi-Fi and Mobile equally"),

    /** Send large downloads via fastest, small requests via both */
    SMART_SPLIT("Smart Split", "Large transfers use fastest link; small requests split evenly"),

    /** Prefer Wi-Fi but instantly failover to Mobile if WiFi degrades */
    WIFI_FIRST("Wi-Fi Priority", "Uses Wi-Fi by default; switches to Mobile if Wi-Fi weakens");

    private final String displayName;
    private final String description;

    LoadBalancerStrategy(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() { return displayName; }
    public String getDescription() { return description; }
}
