package com.expensetracker.sms

import com.expensetracker.data.entities.AccountType
import com.expensetracker.data.entities.TransactionType
import java.text.SimpleDateFormat
import java.util.*

data class ParsedTransaction(
    val amount: Double,
    val type: TransactionType,
    val merchant: String,
    val bankCode: String,
    val accountHint: String,    // last 4 digits or account hint
    val accountType: AccountType,
    val balanceAfter: Double?,
    val reference: String,
    val isTransfer: Boolean,
    val rawSms: String
)

object SmsParser {

    // -- Amount pattern (handles \u20B9, Rs., INR, commas) ------------------------
    private val AMOUNT_RE = Regex(
        """(?:Rs\.?|INR|\u20B9)\s*([0-9,]+(?:\.[0-9]{1,2})?)""",
        RegexOption.IGNORE_CASE
    )

    // -- Balance pattern ------------------------------------------------------
    private val BALANCE_RE = Regex(
        """(?:Avl\.?\s*Bal(?:ance)?|Available\s+Balance|Bal)\s*[:\-]?\s*(?:Rs\.?|INR|\u20B9)?\s*([0-9,]+(?:\.[0-9]{1,2})?)""",
        RegexOption.IGNORE_CASE
    )

    // -- UPI Reference ID -----------------------------------------------------
    private val UPI_REF_RE = Regex(
        """(?:UPI\s*Ref\.?\s*(?:No\.?)?|Ref\s*No\.?|Transaction\s*ID)\s*[:\-]?\s*([0-9]{12,})""",
        RegexOption.IGNORE_CASE
    )

    // -- Card last 4 digits ---------------------------------------------------
    private val CARD_RE = Regex(
        """(?:card|a/c|ac|acct)[\s\w]*?(?:XX+|ending\s+|\.{2,})([0-9]{4})""",
        RegexOption.IGNORE_CASE
    )

    // -- Debit keywords -------------------------------------------------------
    private val DEBIT_RE = Regex(
        """(?:debited|deducted|spent|paid|payment of|purchase|withdrawn|transfer(?:red)? from|dr\b)""",
        RegexOption.IGNORE_CASE
    )

    // -- Credit keywords ------------------------------------------------------
    private val CREDIT_RE = Regex(
        """(?:credited|received|refund|cashback|added|cr\b)""",
        RegexOption.IGNORE_CASE
    )

    // -- Transfer keywords ----------------------------------------------------
    private val TRANSFER_RE = Regex(
        """(?:transfer(?:red)?|NEFT|RTGS|IMPS|UPI\s+transfer|top.?up|recharge)""",
        RegexOption.IGNORE_CASE
    )

    // -- Bank-specific sender patterns -----------------------------------------
    private val BANK_SENDERS = mapOf(
        "HDFC"    to listOf("HDFCBK", "HDFCBANK", "HDFCCC"),
        "SBI"     to listOf("SBIBNK", "SBICRD", "SBIINB", "SBIPSG"),
        "ICICI"   to listOf("ICICIB", "ICICIBANK", "ICICICC"),
        "AXIS"    to listOf("AXISBK", "AXISBANK"),
        "KOTAK"   to listOf("KOTAKB", "KOTAKBANK"),
        "PAYTM"   to listOf("PAYTM", "PYTMBANK"),
        "AIRTEL"  to listOf("AIRTELPAY", "AIRTEL"),
        "JIOPAY"  to listOf("JIOBP", "JIOMONEY"),
        "GPAY"    to listOf("GPAY", "GOOGLE"),
        "PHONEPE" to listOf("PHONEPE", "PHNPE"),
        "YES"     to listOf("YESBNK", "YESBANK"),
        "PNB"     to listOf("PNBSMS", "PUNBNK"),
        "BOB"     to listOf("BARBNK", "BOBBNK"),
        "CANARA"  to listOf("CANBNK", "CANARABANK"),
        "INDUSIND"to listOf("INDBNK", "INDUSLND"),
    )

    // -- Merchant extraction --------------------------------------------------
    private val MERCHANT_PATTERNS = listOf(
        Regex("""(?:at|to|from|towards)\s+([A-Za-z0-9\s&\-]{3,30})""", RegexOption.IGNORE_CASE),
        Regex("""(?:VPA|UPI)\s+([a-zA-Z0-9.\-@]+)""", RegexOption.IGNORE_CASE),
        Regex("""(?:merchant|store)\s*[:\-]?\s*([A-Za-z0-9\s]{3,25})""", RegexOption.IGNORE_CASE),
    )

    fun parse(smsBody: String, sender: String): ParsedTransaction? {
        val body = smsBody.trim()

        // Must have an amount
        val amountMatch = AMOUNT_RE.find(body) ?: return null
        val amount = amountMatch.groupValues[1].replace(",", "").toDoubleOrNull() ?: return null
        if (amount <= 0) return null

        // Determine type
        val isDebit  = DEBIT_RE.containsMatchIn(body)
        val isCredit = CREDIT_RE.containsMatchIn(body)
        val type = when {
            isDebit  -> TransactionType.DEBIT
            isCredit -> TransactionType.CREDIT
            else     -> return null // can't determine type
        }

        // Balance after transaction
        val balanceAfter = BALANCE_RE.find(body)?.groupValues?.get(1)
            ?.replace(",", "")?.toDoubleOrNull()

        // UPI reference
        val reference = UPI_REF_RE.find(body)?.groupValues?.get(1) ?: ""

        // Card/account hint
        val accountHint = CARD_RE.find(body)?.groupValues?.get(1) ?: ""

        // Bank code from sender
        val bankCode = detectBank(sender)

        // Account type
        val accountType = detectAccountType(body, sender)

        // Merchant
        val merchant = extractMerchant(body)

        // Is it a transfer? (wallet top-up, NEFT, IMPS etc.)
        // FIX #7: was accidentally double-negated (!x.not() == x).
        // Correct intent: mark as transfer only when NOT a regular UPI payment
        // (UPI transfers to bank accounts are still flagged by TRANSFER_RE keywords).
        val isTransfer = TRANSFER_RE.containsMatchIn(body) &&
                !body.contains("UPI", ignoreCase = true)

        return ParsedTransaction(
            amount       = amount,
            type         = type,
            merchant     = merchant,
            bankCode     = bankCode,
            accountHint  = accountHint,
            accountType  = accountType,
            balanceAfter = balanceAfter,
            reference    = reference,
            isTransfer   = isTransfer,
            rawSms       = smsBody
        )
    }

    private fun detectBank(sender: String): String {
        val upper = sender.uppercase()
        for ((bank, codes) in BANK_SENDERS) {
            if (codes.any { upper.contains(it) }) return bank
        }
        return "UNKNOWN"
    }

    private fun detectAccountType(body: String, sender: String): AccountType {
        val upper = (body + sender).uppercase()
        return when {
            upper.contains("CREDIT CARD") || upper.contains("CC ") || upper.contains("HDFCCC") -> AccountType.CREDIT_CARD
            upper.contains("WALLET") || upper.contains("PAYTM") || upper.contains("PHONEPAY") -> AccountType.WALLET
            upper.contains("CASH") -> AccountType.CASH
            upper.contains("UPI")  -> AccountType.UPI
            else -> AccountType.SAVINGS
        }
    }

    private fun extractMerchant(body: String): String {
        for (pattern in MERCHANT_PATTERNS) {
            val match = pattern.find(body)
            if (match != null) {
                val m = match.groupValues[1].trim()
                if (m.length >= 3) return m.take(40)
            }
        }
        return ""
    }

    // -- Auto-categorization based on merchant keywords -----------------------
    fun suggestCategory(merchant: String, description: String): String {
        val text = (merchant + " " + description).lowercase()
        return when {
            text.containsAny("swiggy","zomato","pizza","burger","restaurant","cafe","food","dining","eat") -> "Food & Dining"
            text.containsAny("uber","ola","rapido","metro","bus","auto","fuel","petrol","cab") -> "Transport"
            text.containsAny("amazon","flipkart","myntra","ajio","meesho","shop","mall","store") -> "Shopping"
            text.containsAny("electricity","water","gas","broadband","wifi","internet","jio","airtel","bsnl","dth") -> "Bills & Utilities"
            text.containsAny("netflix","hotstar","prime","spotify","youtube","movie","cinema") -> "Entertainment"
            text.containsAny("hospital","clinic","doctor","pharmacy","medicine","health","apollo") -> "Health"
            text.containsAny("bigbasket","grofer","blinkit","zepto","dunzo","kirana","grocery") -> "Groceries"
            text.containsAny("school","college","university","course","udemy","byju","fee") -> "Education"
            text.containsAny("flight","hotel","booking","makemytrip","goibibo","travel","irctc") -> "Travel"
            text.containsAny("transfer","neft","imps","rtgs","wallet","top up","topup") -> "Transfer"
            else -> "Other"
        }
    }

    private fun String.containsAny(vararg keywords: String) = keywords.any { this.contains(it) }
}
