package com.expensetracker.data

import android.content.Context
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.expensetracker.data.dao.AccountDao
import com.expensetracker.data.dao.BudgetDao
import com.expensetracker.data.dao.CategoryDao
import com.expensetracker.data.dao.TransactionDao
import com.expensetracker.data.entities.AccountType
import com.expensetracker.data.entities.TransactionSource
import com.expensetracker.data.entities.TransactionType
import com.expensetracker.data.entities.Account
import com.expensetracker.data.entities.Budget
import com.expensetracker.data.entities.Category
import com.expensetracker.data.entities.Transaction
import com.expensetracker.data.entities.DEFAULT_CATEGORIES
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// -- Type Converters ------------------------------------------------------------

class Converters {
    @TypeConverter fun fromAccountType(v: AccountType): String     = v.name
    @TypeConverter fun toAccountType(v: String): AccountType       = AccountType.valueOf(v)
    @TypeConverter fun fromTxType(v: TransactionType): String      = v.name
    @TypeConverter fun toTxType(v: String): TransactionType        = TransactionType.valueOf(v)
    @TypeConverter fun fromTxSource(v: TransactionSource): String  = v.name
    @TypeConverter fun toTxSource(v: String): TransactionSource    = TransactionSource.valueOf(v)
}

// -- Room Database -- NO SQLCipher imports here so KSP can process cleanly ------
// Encryption is applied in DatabaseFactory (below) via openHelperFactory().

@Database(
    entities     = [Account::class, Category::class, Transaction::class, Budget::class],
    version      = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun accountDao(): AccountDao
    abstract fun categoryDao(): CategoryDao
    abstract fun transactionDao(): TransactionDao
    abstract fun budgetDao(): BudgetDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: DatabaseFactory.build(context).also { INSTANCE = it }
            }
    }
}
