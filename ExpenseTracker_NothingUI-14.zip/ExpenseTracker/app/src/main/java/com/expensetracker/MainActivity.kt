package com.expensetracker

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.*
import com.expensetracker.ui.screens.*
import com.expensetracker.ui.theme.*
import com.expensetracker.viewmodel.MainViewModel
import com.expensetracker.worker.scheduleSmsSync

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* handle result */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestRequiredPermissions()
        scheduleSmsSync(this)
        setContent {
            ExpenseTrackerTheme {
                AppNavigation(viewModel)
            }
        }
    }

    private fun requestRequiredPermissions() {
        val perms = mutableListOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permissionLauncher.launch(perms.toTypedArray())
        if (!isNotificationListenerEnabled())
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val cn   = "${packageName}/.sms.TransactionNotificationListener"
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat?.contains(cn) == true
    }
}

data class NavItem(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val iconSelected: ImageVector
)

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val navController = rememberNavController()

    // Using only icons that are guaranteed to exist in material-icons-extended
    val items = listOf(
        NavItem("home",         "Home",     Icons.Outlined.Home,           Icons.Filled.Home),
        NavItem("transactions", "Txns",     Icons.Outlined.List,           Icons.Filled.List),
        NavItem("accounts",     "Accounts", Icons.Outlined.AccountBalance,  Icons.Filled.AccountBalance),
        NavItem("budgets",      "Budget",   Icons.Outlined.PieChart,        Icons.Filled.PieChart),
        NavItem("reports",      "Reports",  Icons.Outlined.BarChart,        Icons.Filled.BarChart),
    )

    Scaffold(
        containerColor = Black,
        bottomBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Black)
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                HorizontalDivider(
                    color     = Border,
                    thickness = 0.5.dp,
                    modifier  = Modifier.align(Alignment.TopStart)
                )
                NavigationBar(
                    containerColor = Black,
                    tonalElevation = 0.dp,
                    modifier       = Modifier.height(62.dp)
                ) {
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentDest = navBackStackEntry?.destination

                    items.forEach { item ->
                        val selected = currentDest?.hierarchy?.any { it.route == item.route } == true
                        NavigationBarItem(
                            icon = {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    if (selected) {
                                        Box(
                                            modifier = Modifier
                                                .size(4.dp)
                                                .background(NothingRed, RoundedCornerShape(50))
                                        )
                                        Spacer(Modifier.height(2.dp))
                                    } else {
                                        Spacer(Modifier.height(6.dp))
                                    }
                                    Icon(
                                        imageVector     = if (selected) item.iconSelected else item.icon,
                                        contentDescription = item.label,
                                        modifier        = Modifier.size(20.dp)
                                    )
                                }
                            },
                            label = {
                                Text(
                                    item.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) White else DimText
                                )
                            },
                            selected = selected,
                            onClick  = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.startDestinationId) { saveState = true }
                                    launchSingleTop = true
                                    restoreState    = true
                                }
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor   = White,
                                unselectedIconColor = DimText,
                                indicatorColor      = Black
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController    = navController,
            startDestination = "home",
            modifier         = Modifier.padding(innerPadding)
        ) {
            composable("home")         { HomeScreen(viewModel, navController) }
            composable("transactions") { TransactionsScreen(viewModel) }
            composable("accounts")     { AccountsScreen(viewModel) }
            composable("budgets")      { BudgetScreen(viewModel) }
            composable("reports")      { ReportsScreen(viewModel) }
        }
    }
}
