package com.expensetracker.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.expensetracker.data.entities.Transaction
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object CsvExporter {

    /**
     * FIX #10: Proper RFC 4180 CSV escaping.
     * Wraps every field in double-quotes and escapes internal double-quotes as "".
     * This correctly handles commas, newlines, and quotes inside field values.
     */
    private fun csvField(value: String): String {
        val escaped = value.replace("\"", "\"\"")
        return "\"$escaped\""
    }

    fun export(
        context: Context,
        transactions: List<Transaction>,
        categoryName: (Int?) -> String,
        accountName: (Int?) -> String
    ) {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val sb  = StringBuilder()

        // Header row
        sb.appendLine(listOf("Date", "Type", "Amount", "Account", "Category", "Merchant", "Description", "Reference")
            .joinToString(",") { csvField(it) })

        transactions.forEach { tx ->
            sb.appendLine(listOf(
                sdf.format(Date(tx.date)),
                tx.type.name,
                tx.amount.toString(),
                accountName(tx.accountId),
                categoryName(tx.categoryId),
                tx.merchant,
                tx.description.take(80),
                tx.reference
            ).joinToString(",") { csvField(it) })
        }

        val fileName = "expenses_${SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())}.csv"
        val file     = File(context.cacheDir, fileName)
        file.writeText(sb.toString())

        val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val intent   = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Export CSV").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }
}
