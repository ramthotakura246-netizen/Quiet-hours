package com.expensetracker.data

import android.content.Context
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import com.expensetracker.data.entities.DEFAULT_CATEGORIES
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

/**
 * Builds the encrypted Room database.
 * All SQLCipher types are isolated here so KSP never sees them
 * when processing the @Database class (AppDatabase).
 */
object DatabaseFactory {

    /**
     * Derives a per-installation passphrase from the package name and device
     * fingerprint. The raw .db file is unreadable outside this installation.
     * For stronger protection, generate a random key on first run and store
     * it in the Android Keystore.
     */
    private fun passphrase(context: Context): ByteArray {
        val seed = "${context.packageName}:${android.os.Build.FINGERPRINT}"
        return java.security.MessageDigest
            .getInstance("SHA-256")
            .digest(seed.toByteArray(Charsets.UTF_8))
    }

    fun build(context: Context): AppDatabase {
        SQLiteDatabase.loadLibs(context)
        val factory = SupportFactory(passphrase(context))

        return Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "expense_tracker.db"
        )
        .openHelperFactory(factory)
        .addCallback(object : androidx.room.RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                CoroutineScope(Dispatchers.IO).launch {
                    AppDatabase.getInstance(context).categoryDao().insertAll(DEFAULT_CATEGORIES)
                }
            }
        })
        .build()
    }
}
