package com.expensetracker.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.expensetracker.ui.theme.*
import com.expensetracker.viewmodel.MainViewModel
import com.expensetracker.viewmodel.MainViewModel.Companion.formatMonth
import java.text.NumberFormat
import java.util.Locale

// -- Shared UI primitives (used by HomeScreen + OtherScreens) ------------------

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Box(Modifier.size(4.dp).background(NothingRed, RoundedCornerShape(50)))
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.labelMedium, color = DimText)
    }
}

@Composable
fun NothingDivider() = HorizontalDivider(color = Border, thickness = 0.5.dp)

// -- Home Screen ----------------------------------------------------------------

@Composable
fun HomeScreen(vm: MainViewModel, navController: NavController) {
    val monthYear  by vm.monthYear.collectAsState()
    val accounts   by vm.accounts.collectAsState()
    val totalSpent by vm.totalSpent.collectAsState()
    val recentTx   by vm.recentTx.collectAsState()

    val fmt = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black)
            .verticalScroll(rememberScrollState())
    ) {

        // -- Top bar ---------------------------------------------------------
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Black)
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text  = "EXPENDR",
                style = MaterialTheme.typography.headlineLarge,
                color = White
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(Surface2, RoundedCornerShape(50))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Box(Modifier.size(5.dp).background(NothingRed, RoundedCornerShape(50)))
                Spacer(Modifier.width(5.dp))
                Text("LIVE", style = MaterialTheme.typography.labelSmall, color = MidText)
            }
        }

        NothingDivider()

        // -- Month switcher ---------------------------------------------------
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { vm.prevMonth() }) {
                Icon(Icons.Default.ChevronLeft, contentDescription = "Prev", tint = MidText)
            }
            Text(
                text  = formatMonth(monthYear).uppercase(),
                style = MaterialTheme.typography.labelLarge,
                color = MidText
            )
            IconButton(onClick = { vm.nextMonth() }) {
                Icon(Icons.Default.ChevronRight, contentDescription = "Next", tint = MidText)
            }
        }

        NothingDivider()

        // -- Hero spend amount ------------------------------------------------
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 28.dp)
        ) {
            Text(
                text  = "TOTAL SPENT",
                style = MaterialTheme.typography.labelMedium,
                color = DimText
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text  = fmt.format(totalSpent ?: 0.0),
                style = MaterialTheme.typography.displayLarge.copy(fontSize = 48.sp),
                color = White
            )
        }

        NothingDivider()

        // -- Accounts ---------------------------------------------------------
        SectionLabel("ACCOUNTS")

        accounts.forEach { account ->
            val accountSpend by vm.accountSpend(account.id).collectAsState(initial = null)
            val spent  = accountSpend ?: 0.0
            val total  = (totalSpent ?: 1.0).let { if (it == 0.0) 1.0 else it }
            val pct    = if (spent > 0) ((spent / total) * 100).toInt() else 0
            val accentColor = try {
                Color(android.graphics.Color.parseColor(account.color))
            } catch (e: Exception) { GreenAccent }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { navController.navigate("transactions") }
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            text  = account.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = White
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text  = account.type.name.replace("_", " "),
                            style = MaterialTheme.typography.labelSmall,
                            color = DimText
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text  = fmt.format(spent),
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = White
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text  = "BAL ${fmt.format(account.balance)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = DimText
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.5.dp)
                        .background(BorderBright, RoundedCornerShape(1.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth((pct / 100f).coerceIn(0f, 1f))
                            .fillMaxHeight()
                            .background(accentColor, RoundedCornerShape(1.dp))
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text("$pct% of total spend", style = MaterialTheme.typography.labelSmall, color = DimText)
            }

            NothingDivider()
        }

        // -- Recent transactions ----------------------------------------------
        SectionLabel("RECENT")

        recentTx.take(10).forEach { tx ->
            val isCredit = tx.type.name == "CREDIT"
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f).padding(end = 12.dp)) {
                    Text(
                        text  = tx.merchant.ifBlank { tx.description }.take(32),
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                        color = White,
                        maxLines = 1
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text  = "${vm.categoryIcon(tx.categoryId)}  ${vm.categoryName(tx.categoryId)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = DimText
                    )
                }
                Text(
                    text  = "${if (isCredit) "+" else "−"}${fmt.format(tx.amount)}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (isCredit) GreenAccent else White
                )
            }
            NothingDivider()
        }

        Spacer(Modifier.height(24.dp))
    }
}
