package com.expensetracker.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.expensetracker.data.entities.*
import com.expensetracker.ui.theme.*
import com.expensetracker.viewmodel.MainViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

// -- Shared text-field helpers -- used across this file and OtherScreens --------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun monoTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor      = White,
    unfocusedBorderColor    = Border,
    focusedTextColor        = White,
    unfocusedTextColor      = White,
    focusedLabelColor       = DimText,
    unfocusedLabelColor     = DimText,
    cursorColor             = White,
    focusedContainerColor   = Surface2,
    unfocusedContainerColor = Surface2,
    errorBorderColor        = NothingRed,
    errorLabelColor         = NothingRed
)

@Composable
fun MonoTextField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value         = value,
        onValueChange = onChange,
        label         = { Text(label, style = MaterialTheme.typography.labelMedium) },
        modifier      = Modifier.fillMaxWidth(),
        colors        = monoTextFieldColors(),
        shape         = RoundedCornerShape(4.dp),
        textStyle     = MaterialTheme.typography.bodyMedium,
        singleLine    = true
    )
}

// -- Transactions Screen --------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun TransactionsScreen(vm: MainViewModel) {
    val transactions by vm.monthTransactions.collectAsState()
    val categories   by vm.categories.collectAsState()
    val accounts     by vm.accounts.collectAsState()

    var showAddSheet by remember { mutableStateOf(false) }
    var searchQuery  by remember { mutableStateOf("") }
    var filterType   by remember { mutableStateOf("ALL") }

    val fmt     = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    val dateFmt = SimpleDateFormat("dd MMM", Locale.getDefault())

    val filtered = transactions.filter { tx ->
        val matchSearch = searchQuery.isBlank() ||
            tx.merchant.contains(searchQuery, ignoreCase = true) ||
            tx.description.contains(searchQuery, ignoreCase = true)
        val matchType = filterType == "ALL" ||
            (filterType == "DEBIT"  && tx.type == TransactionType.DEBIT) ||
            (filterType == "CREDIT" && tx.type == TransactionType.CREDIT)
        matchSearch && matchType
    }

    Scaffold(
        containerColor = Black,
        floatingActionButton = {
            FloatingActionButton(
                onClick        = { showAddSheet = true },
                containerColor = White,
                contentColor   = Black,
                shape          = RoundedCornerShape(4.dp)
            ) { Icon(Icons.Default.Add, "Add") }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Black)
        ) {
            // Header
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Black)
                        .padding(horizontal = 20.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("TRANSACTIONS", style = MaterialTheme.typography.headlineLarge, color = White)
                }
                NothingDivider()
            }

            // Search bar
            OutlinedTextField(
                value         = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder   = { Text("Search...", style = MaterialTheme.typography.labelMedium, color = DimText) },
                modifier      = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                colors        = monoTextFieldColors(),
                shape         = RoundedCornerShape(4.dp),
                textStyle     = MaterialTheme.typography.bodyMedium,
                singleLine    = true
            )

            // Filter chips
            Row(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("ALL", "DEBIT", "CREDIT").forEach { type ->
                    FilterChip(
                        selected = filterType == type,
                        onClick  = { filterType = type },
                        label    = { Text(type, style = MaterialTheme.typography.labelSmall) },
                        shape    = RoundedCornerShape(4.dp),
                        colors   = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = White,
                            selectedLabelColor     = Black,
                            labelColor             = DimText
                        )
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Transaction list
            LazyColumn(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                items(filtered, key = { it.id }) { tx ->
                    var showDelete by remember { mutableStateOf(false) }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Surface1)
                            .combinedClickable(
                                onClick     = {},
                                onLongClick = { showDelete = true }
                            )
                    ) {
                        // Left colour bar
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(64.dp)
                                .background(
                                    when {
                                        tx.type == TransactionType.CREDIT -> GreenAccent
                                        tx.isTransfer                     -> DimText
                                        else                              -> NothingRed
                                    }
                                )
                        )
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        text     = tx.merchant.ifBlank { "Manual Entry" },
                                        style    = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color    = White,
                                        maxLines = 1
                                    )
                                    Text(
                                        text  = "${vm.categoryIcon(tx.categoryId)} ${vm.categoryName(tx.categoryId)} . ${vm.accountName(tx.accountId)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = DimText
                                    )
                                    if (tx.isTransfer) {
                                        Text("TRANSFER", style = MaterialTheme.typography.labelSmall, color = DimText)
                                    }
                                    if (tx.source == TransactionSource.SMS || tx.source == TransactionSource.NOTIFICATION) {
                                        Text(
                                            "* AUTO",
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                            color = GreenAccent
                                        )
                                    }
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text  = "${if (tx.type == TransactionType.CREDIT) "+" else "−"}${fmt.format(tx.amount)}",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = if (tx.type == TransactionType.CREDIT) GreenAccent else White
                                    )
                                    Text(
                                        dateFmt.format(Date(tx.date)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = DimText
                                    )
                                }
                            }
                        }
                    }
                    NothingDivider()

                    if (showDelete) {
                        AlertDialog(
                            onDismissRequest = { showDelete = false },
                            title            = { Text("DELETE?", style = MaterialTheme.typography.titleMedium, color = White) },
                            text             = { Text("Remove this transaction?", style = MaterialTheme.typography.bodyMedium, color = MidText) },
                            confirmButton    = {
                                TextButton(onClick = { vm.deleteTransaction(tx); showDelete = false }) {
                                    Text("DELETE", color = NothingRed)
                                }
                            },
                            dismissButton    = {
                                TextButton(onClick = { showDelete = false }) {
                                    Text("CANCEL", color = White)
                                }
                            },
                            containerColor = Surface1
                        )
                    }
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    if (showAddSheet) {
        AddTransactionSheet(
            vm         = vm,
            accounts   = accounts,
            categories = categories,
            onDismiss  = { showAddSheet = false }
        )
    }
}

// -- Add Transaction Bottom Sheet -----------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionSheet(
    vm: MainViewModel,
    accounts: List<Account>,
    categories: List<Category>,
    onDismiss: () -> Unit
) {
    var amount      by remember { mutableStateOf("") }
    var amountError by remember { mutableStateOf(false) }
    var merchant    by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedAcc by remember { mutableStateOf(accounts.firstOrNull()) }
    var selectedCat by remember { mutableStateOf(categories.firstOrNull()) }
    var txType      by remember { mutableStateOf(TransactionType.DEBIT) }
    var isTransfer  by remember { mutableStateOf(false) }
    var toAccount   by remember { mutableStateOf<Account?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor   = Surface1,
        shape            = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("ADD TRANSACTION", style = MaterialTheme.typography.headlineMedium, color = White)
            NothingDivider()
            Spacer(Modifier.height(16.dp))

            // Type selector
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(TransactionType.DEBIT, TransactionType.CREDIT).forEach { type ->
                    FilterChip(
                        selected = txType == type && !isTransfer,
                        onClick  = { txType = type; isTransfer = false },
                        label    = { Text(type.name, style = MaterialTheme.typography.labelSmall) },
                        shape    = RoundedCornerShape(4.dp),
                        colors   = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = if (type == TransactionType.DEBIT) NothingRed else GreenAccent,
                            selectedLabelColor     = Black,
                            labelColor             = DimText
                        )
                    )
                }
                FilterChip(
                    selected = isTransfer,
                    onClick  = { isTransfer = true },
                    label    = { Text("TRANSFER", style = MaterialTheme.typography.labelSmall) },
                    shape    = RoundedCornerShape(4.dp),
                    colors   = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BorderBright,
                        selectedLabelColor     = White,
                        labelColor             = DimText
                    )
                )
            }

            Spacer(Modifier.height(12.dp))

            // Amount with validation
            OutlinedTextField(
                value         = amount,
                onValueChange = { amount = it; amountError = false },
                label         = { Text("Amount (₹)", style = MaterialTheme.typography.labelMedium) },
                modifier      = Modifier.fillMaxWidth(),
                shape         = RoundedCornerShape(4.dp),
                colors        = monoTextFieldColors(),
                textStyle     = MaterialTheme.typography.bodyMedium,
                singleLine    = true,
                isError       = amountError,
                supportingText = if (amountError) {
                    { Text("Enter a valid amount", color = NothingRed, style = MaterialTheme.typography.labelSmall) }
                } else null
            )
            Spacer(Modifier.height(8.dp))
            MonoTextField("Merchant / Payee", merchant) { merchant = it }
            Spacer(Modifier.height(8.dp))
            MonoTextField("Notes", description) { description = it }
            Spacer(Modifier.height(12.dp))

            // From Account dropdown
            Text("ACCOUNT", style = MaterialTheme.typography.labelMedium, color = DimText)
            Spacer(Modifier.height(4.dp))
            var accExpanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(
                expanded         = accExpanded,
                onExpandedChange = { accExpanded = it }
            ) {
                OutlinedTextField(
                    value         = selectedAcc?.name ?: "SELECT",
                    onValueChange = {},
                    readOnly      = true,
                    modifier      = Modifier
                        .fillMaxWidth()
                        .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                    colors        = monoTextFieldColors(),
                    shape         = RoundedCornerShape(4.dp),
                    textStyle     = MaterialTheme.typography.bodyMedium
                )
                ExposedDropdownMenu(
                    expanded         = accExpanded,
                    onDismissRequest = { accExpanded = false },
                    modifier         = Modifier.background(Surface2)
                ) {
                    accounts.forEach { acc ->
                        DropdownMenuItem(
                            text    = { Text(acc.name, style = MaterialTheme.typography.bodyMedium, color = White) },
                            onClick = { selectedAcc = acc; accExpanded = false }
                        )
                    }
                }
            }

            // To Account (transfers only)
            if (isTransfer) {
                Spacer(Modifier.height(8.dp))
                Text("TO ACCOUNT", style = MaterialTheme.typography.labelMedium, color = DimText)
                Spacer(Modifier.height(4.dp))
                var toExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded         = toExpanded,
                    onExpandedChange = { toExpanded = it }
                ) {
                    OutlinedTextField(
                        value         = toAccount?.name ?: "SELECT",
                        onValueChange = {},
                        readOnly      = true,
                        modifier      = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                        colors        = monoTextFieldColors(),
                        shape         = RoundedCornerShape(4.dp),
                        textStyle     = MaterialTheme.typography.bodyMedium
                    )
                    ExposedDropdownMenu(
                        expanded         = toExpanded,
                        onDismissRequest = { toExpanded = false },
                        modifier         = Modifier.background(Surface2)
                    ) {
                        accounts.filter { it.id != selectedAcc?.id }.forEach { acc ->
                            DropdownMenuItem(
                                text    = { Text(acc.name, style = MaterialTheme.typography.bodyMedium, color = White) },
                                onClick = { toAccount = acc; toExpanded = false }
                            )
                        }
                    }
                }
            }

            // Category (non-transfers only)
            if (!isTransfer) {
                Spacer(Modifier.height(8.dp))
                Text("CATEGORY", style = MaterialTheme.typography.labelMedium, color = DimText)
                Spacer(Modifier.height(4.dp))
                var catExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded         = catExpanded,
                    onExpandedChange = { catExpanded = it }
                ) {
                    OutlinedTextField(
                        value         = "${selectedCat?.icon ?: ""} ${selectedCat?.name ?: "SELECT"}",
                        onValueChange = {},
                        readOnly      = true,
                        modifier      = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                        colors        = monoTextFieldColors(),
                        shape         = RoundedCornerShape(4.dp),
                        textStyle     = MaterialTheme.typography.bodyMedium
                    )
                    ExposedDropdownMenu(
                        expanded         = catExpanded,
                        onDismissRequest = { catExpanded = false },
                        modifier         = Modifier.background(Surface2)
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text    = { Text("${cat.icon} ${cat.name}", style = MaterialTheme.typography.bodyMedium, color = White) },
                                onClick = { selectedCat = cat; catExpanded = false }
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    val amt = amount.toDoubleOrNull()
                    if (amt == null || amt <= 0) { amountError = true; return@Button }
                    vm.addTransaction(Transaction(
                        amount      = amt,
                        type        = if (isTransfer) TransactionType.TRANSFER else txType,
                        accountId   = selectedAcc?.id,
                        toAccountId = if (isTransfer) toAccount?.id else null,
                        categoryId  = selectedCat?.id,
                        merchant    = merchant,
                        description = description,
                        isTransfer  = isTransfer,
                        source      = TransactionSource.MANUAL
                    ))
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(4.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black)
            ) {
                Text("SAVE TRANSACTION", style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}
