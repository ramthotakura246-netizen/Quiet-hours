package com.expensetracker.worker

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.expensetracker.data.AppDatabase
import com.expensetracker.sms.SmsParser
import com.expensetracker.sms.SmsReceiver

/**
 * Reads the SMS inbox on first run (or periodic sync) to catch any
 * bank messages that arrived before the app was installed.
 * Only processes messages newer than the last successful sync.
 */
class SmsSyncWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    companion object {
        private const val PREFS_NAME            = "sms_sync_prefs"
        private const val KEY_LAST_SYNC         = "last_sync_timestamp_ms"
        private const val FIRST_RUN_LOOKBACK_MS = 90L * 24 * 60 * 60 * 1000 // 90 days
    }

    private fun prefs(): SharedPreferences =
        applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    override suspend fun doWork(): Result {
        val context  = applicationContext
        val db       = AppDatabase.getInstance(context)
        val lastSync = prefs().getLong(KEY_LAST_SYNC, 0L)
        val since    = if (lastSync == 0L)
            System.currentTimeMillis() - FIRST_RUN_LOOKBACK_MS
        else
            lastSync

        // Only fetch SMS newer than the last sync timestamp
        val cursor = context.contentResolver.query(
            Uri.parse("content://sms/inbox"),
            arrayOf("address", "body", "date"),
            "date > ?",
            arrayOf(since.toString()),
            "date DESC"
        ) ?: return Result.success()

        cursor.use {
            val addrIdx = it.getColumnIndex("address")
            val bodyIdx = it.getColumnIndex("body")
            while (it.moveToNext()) {
                val sender = it.getString(addrIdx) ?: continue
                val body   = it.getString(bodyIdx)  ?: continue
                val parsed = SmsParser.parse(body, sender) ?: continue
                SmsReceiver.processParsedSms(context, db, parsed, sender)
            }
        }

        prefs().edit().putLong(KEY_LAST_SYNC, System.currentTimeMillis()).apply()
        return Result.success()
    }
}
