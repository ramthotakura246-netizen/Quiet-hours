package com.expensetracker.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.expensetracker.data.AppDatabase
import com.expensetracker.data.entities.Transaction
import com.expensetracker.data.entities.TransactionSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.security.MessageDigest

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val db = AppDatabase.getInstance(context)

        // goAsync() keeps the process alive until the coroutine finishes
        val pendingResult = goAsync()
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

        scope.launch {
            try {
                messages.forEach { sms ->
                    val body   = sms.messageBody ?: return@forEach
                    val sender = sms.originatingAddress ?: ""
                    val parsed = SmsParser.parse(body, sender) ?: return@forEach
                    processParsedSms(context, db, parsed, sender)
                }
            } finally {
                pendingResult.finish()
                scope.cancel()
            }
        }
    }

    companion object {

        /**
         * Deterministic dedup key for transactions without a UPI reference
         * (card swipes, ATM withdrawals). SHA-256 hash of stable fields
         * rounded to the nearest minute to tolerate minor timestamp drift.
         */
        private fun fingerprintHash(parsed: ParsedTransaction, sender: String): String {
            val minuteTs = (System.currentTimeMillis() / 60_000) * 60_000
            val raw      = "${parsed.amount}|${parsed.type}|${parsed.accountHint}|${sender}|${minuteTs}"
            val digest   = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
            return digest.joinToString("") { "%02x".format(it) }
        }

        suspend fun processParsedSms(
            context: Context,
            db: AppDatabase,
            parsed: ParsedTransaction,
            sender: String
        ) {
            // Dedup: UPI ref when available, else fingerprint hash
            val dedupKey = parsed.reference.ifBlank { fingerprintHash(parsed, sender) }
            if (db.transactionDao().findByReference(dedupKey) != null) return

            // Collect accounts once from the Flow
            val accounts = db.accountDao().getAllAccounts().first()
            var accountId: Int? = null

            if (parsed.accountHint.isNotBlank()) {
                accountId = accounts.firstOrNull { acc ->
                    acc.bankCode.equals(parsed.bankCode, ignoreCase = true) &&
                    acc.cardLastFour == parsed.accountHint
                }?.id
            }
            if (accountId == null && parsed.bankCode != "UNKNOWN") {
                accountId = accounts.firstOrNull { acc ->
                    acc.bankCode.equals(parsed.bankCode, ignoreCase = true)
                }?.id
            }

            if (parsed.balanceAfter != null && accountId != null) {
                db.accountDao().updateBalance(accountId, parsed.balanceAfter)
            }

            val allCats = db.categoryDao().getAllCategories().first()
            val suggestedName = SmsParser.suggestCategory(parsed.merchant, parsed.bankCode)
            val categoryId = allCats.firstOrNull {
                it.name.equals(suggestedName, ignoreCase = true)
            }?.id

            // Never store raw SMS content -- only safe parsed fields
            val transaction = Transaction(
                amount       = parsed.amount,
                type         = parsed.type,
                accountId    = accountId,
                categoryId   = categoryId,
                merchant     = parsed.merchant,
                description  = parsed.merchant.ifBlank { parsed.bankCode },
                source       = TransactionSource.SMS,
                rawSms       = "",
                isTransfer   = parsed.isTransfer,
                balanceAfter = parsed.balanceAfter,
                reference    = dedupKey
            )
            db.transactionDao().insert(transaction)
        }
    }
}
