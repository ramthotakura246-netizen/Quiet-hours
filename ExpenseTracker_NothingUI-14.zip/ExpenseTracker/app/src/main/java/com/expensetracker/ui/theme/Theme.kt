package com.expensetracker.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Nothing OS colour palette
val Black        = Color(0xFF000000)
val Surface1     = Color(0xFF0A0A0A)
val Surface2     = Color(0xFF111111)
val Surface3     = Color(0xFF181818)
val Border       = Color(0xFF1E1E1E)
val BorderBright = Color(0xFF2A2A2A)
val NothingRed   = Color(0xFFFF0000)
val White        = Color(0xFFFFFFFF)
val OffWhite     = Color(0xFFE8E8E8)
val DimText      = Color(0xFF555555)
val MidText      = Color(0xFF888888)
val GreenAccent  = Color(0xFF00E5A0)

private val DarkColorScheme = darkColorScheme(
    primary          = White,
    onPrimary        = Black,
    secondary        = NothingRed,
    onSecondary      = White,
    background       = Black,
    onBackground     = White,
    surface          = Surface1,
    onSurface        = White,
    surfaceVariant   = Surface2,
    outline          = Border,
    error            = NothingRed,
)

val AppTypography = Typography(
    displayLarge   = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,     fontSize = 40.sp, letterSpacing = (-1).sp),
    displayMedium  = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,     fontSize = 28.sp),
    displaySmall   = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,     fontSize = 22.sp),
    headlineLarge  = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,     fontSize = 22.sp, letterSpacing = 3.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,     fontSize = 18.sp, letterSpacing = 3.sp),
    titleMedium    = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, letterSpacing = 1.sp),
    titleSmall     = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Normal,   fontSize = 11.sp, letterSpacing = 1.5.sp),
    bodyLarge      = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Normal,   fontSize = 14.sp),
    bodyMedium     = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Normal,   fontSize = 13.sp),
    bodySmall      = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Normal,   fontSize = 11.sp),
    labelLarge     = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium,   fontSize = 11.sp, letterSpacing = 2.sp),
    labelMedium    = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Normal,   fontSize = 10.sp, letterSpacing = 2.sp),
    labelSmall     = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Normal,   fontSize =  9.sp, letterSpacing = 2.sp),
)

@Composable
fun ExpenseTrackerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = AppTypography,
        content     = content
    )
}
