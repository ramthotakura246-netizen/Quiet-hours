#!/bin/bash
set -e

SDK_DIR="$HOME/android-sdk"

# Skip if already installed
if [ -f "$SDK_DIR/.installed" ]; then
  echo "Android SDK already installed, skipping."
  exit 0
fi

echo ">>> Installing Android SDK..."
mkdir -p "$SDK_DIR/cmdline-tools"

# Download command-line tools
wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O /tmp/cmdtools.zip
unzip -q /tmp/cmdtools.zip -d /tmp/cmdtools
mv /tmp/cmdtools/cmdline-tools "$SDK_DIR/cmdline-tools/latest"
rm -rf /tmp/cmdtools /tmp/cmdtools.zip

# Accept licenses and install SDK components
yes | "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" \
  --sdk_root="$SDK_DIR" \
  "platform-tools" \
  "platforms;android-34" \
  "build-tools;34.0.0" \
  > /dev/null

echo ">>> Installing Gradle wrapper jar..."
mkdir -p "$GITHUB_WORKSPACE/gradle/wrapper"  2>/dev/null || true
WRAPPER_JAR="gradle/wrapper/gradle-wrapper.jar"
if [ ! -f "$WRAPPER_JAR" ]; then
  wget -q "https://github.com/gradle/gradle/raw/v8.5.0/gradle/wrapper/gradle-wrapper.jar" \
    -O "$WRAPPER_JAR"
fi

echo ">>> Writing local.properties..."
echo "sdk.dir=$SDK_DIR" > "$GITHUB_WORKSPACE/local.properties" 2>/dev/null || \
echo "sdk.dir=$SDK_DIR" > local.properties

touch "$SDK_DIR/.installed"
echo ">>> Setup complete."
