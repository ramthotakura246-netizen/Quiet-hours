package com.expensetracker.data

import android.content.Context
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import com.expensetracker.data.dao.AccountDao
import com.expensetracker.data.dao.BudgetDao
import com.expensetracker.data.dao.CategoryDao
import com.expensetracker.data.dao.TransactionDao
import com.expensetracker.data.entities.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

class Converters {
    @TypeConverter fun fromAccountType(v: AccountType): String = v.name
    @TypeConverter fun toAccountType(v: String): AccountType   = AccountType.valueOf(v)
    @TypeConverter fun fromTxType(v: TransactionType): String  = v.name
    @TypeConverter fun toTxType(v: String): TransactionType    = TransactionType.valueOf(v)
    @TypeConverter fun fromTxSource(v: TransactionSource): String = v.name
    @TypeConverter fun toTxSource(v: String): TransactionSource   = TransactionSource.valueOf(v)
}

@Database(
    entities = [Account::class, Category::class, Transaction::class, Budget::class],
    version  = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun accountDao(): AccountDao
    abstract fun categoryDao(): CategoryDao
    abstract fun transactionDao(): TransactionDao
    abstract fun budgetDao(): BudgetDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        /**
         * Derives a per-installation encryption key.
         * The DB file is unreadable if extracted to another device.
         */
        private fun dbPassphrase(context: Context): ByteArray {
            val seed = "${context.packageName}:${android.os.Build.FINGERPRINT}"
            return java.security.MessageDigest
                .getInstance("SHA-256")
                .digest(seed.toByteArray(Charsets.UTF_8))
        }

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context).also { INSTANCE = it }
            }

        private fun buildDatabase(context: Context): AppDatabase {
            SQLiteDatabase.loadLibs(context)
            val factory = SupportFactory(dbPassphrase(context))
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "expense_tracker.db"
            )
            .openHelperFactory(factory)
            .addCallback(object : Callback() {
                override fun onCreate(db: SupportSQLiteDatabase) {
                    super.onCreate(db)
                    CoroutineScope(Dispatchers.IO).launch {
                        INSTANCE?.categoryDao()?.insertAll(DEFAULT_CATEGORIES)
                    }
                }
            })
            .build()
        }
    }
}
