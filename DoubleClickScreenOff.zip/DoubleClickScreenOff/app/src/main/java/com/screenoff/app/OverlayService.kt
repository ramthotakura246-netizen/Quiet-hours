package com.screenoff.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private val handler = Handler(Looper.getMainLooper())

    private var lastClickTime = 0L
    private val DOUBLE_CLICK_THRESHOLD = 450L
    private val TOP_ZONE_FRACTION = 0.08f

    companion object {
        const val CHANNEL_ID = "screen_off_overlay"
        const val NOTIF_ID = 1001
        const val TAG = "OverlayService"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        addOverlay()
    }

    private fun addOverlay() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(metrics)
        val screenWidth = metrics.widthPixels
        val screenHeight = metrics.heightPixels
        val topZoneHeight = (screenHeight * TOP_ZONE_FRACTION).toInt()

        val params = WindowManager.LayoutParams(
            screenWidth,
            topZoneHeight,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }

        val view = View(this).apply {
            setBackgroundColor(0x00000000) // fully transparent
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_DOWN) {
                    handleClick(event.rawX, event.rawY)
                }
                // Pass through: return false so underlying views still receive events
                false
            }
        }

        overlayView = view
        try {
            windowManager.addView(view, params)
            Log.d(TAG, "Overlay added: width=$screenWidth height=$topZoneHeight")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to add overlay: ${e.message}")
        }
    }

    private fun handleClick(x: Float, y: Float) {
        val now = System.currentTimeMillis()
        val delta = now - lastClickTime
        Log.d(TAG, "Click at ($x, $y), delta=${delta}ms")

        if (delta in 1..DOUBLE_CLICK_THRESHOLD) {
            lastClickTime = 0L
            Log.d(TAG, "Double-click! Locking screen.")
            lockScreen()
        } else {
            lastClickTime = now
        }
    }

    private fun lockScreen() {
        ScreenOffService.instance?.let {
            handler.postDelayed({ it.lockScreen() }, 50)
        } ?: run {
            // Fallback: use DevicePolicyManager directly
            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
            val admin = android.content.ComponentName(this, ScreenOffAdminReceiver::class.java)
            if (dpm.isAdminActive(admin)) {
                dpm.lockNow()
            }
        }
    }

    override fun onDestroy() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Screen Off Overlay",
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Running overlay to detect top-bar double-click" }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Screen Off Active")
            .setContentText("Double-click top of screen to lock")
            .setSmallIcon(android.R.drawable.ic_lock_power_off)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }
}

// Extension to make lockScreen accessible
fun ScreenOffService.lockScreen() {
    val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
    val admin = android.content.ComponentName(this, ScreenOffAdminReceiver::class.java)
    if (dpm.isAdminActive(admin)) dpm.lockNow()
}
