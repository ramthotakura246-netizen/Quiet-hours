package com.screenoff.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.MotionEvent
import android.view.WindowManager

class ScreenOffService : AccessibilityService() {

    private lateinit var devicePolicyManager: DevicePolicyManager
    private lateinit var adminComponent: ComponentName
    private val handler = Handler(Looper.getMainLooper())

    // Double-click detection
    private var lastClickTime = 0L
    private val DOUBLE_CLICK_THRESHOLD = 500L // ms between clicks

    // Top zone: top 8% of screen height
    private val TOP_ZONE_FRACTION = 0.08f

    override fun onServiceConnected() {
        super.onServiceConnected()
        devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        adminComponent = ComponentName(this, ScreenOffAdminReceiver::class.java)

        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED or
                         AccessibilityEvent.TYPE_TOUCH_INTERACTION_START
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 50
        }
        serviceInfo = info
        Log.d(TAG, "ScreenOffService connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Handled via gesture/touch overlay instead
    }

    override fun onInterrupt() {
        Log.d(TAG, "ScreenOffService interrupted")
    }

    override fun onGesture(gestureId: Int): Boolean {
        return super.onGesture(gestureId)
    }

    // Called from the overlay touch listener
    fun handleTouch(x: Float, y: Float) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getMetrics(metrics)
        val screenHeight = metrics.heightPixels
        val topZoneHeight = screenHeight * TOP_ZONE_FRACTION

        if (y <= topZoneHeight) {
            val now = System.currentTimeMillis()
            if (now - lastClickTime <= DOUBLE_CLICK_THRESHOLD) {
                // Double click detected in top zone!
                lastClickTime = 0L
                lockScreen()
            } else {
                lastClickTime = now
            }
        }
    }

    private fun lockScreen() {
        if (devicePolicyManager.isAdminActive(adminComponent)) {
            Log.d(TAG, "Locking screen via DevicePolicyManager")
            devicePolicyManager.lockNow()
        } else {
            Log.w(TAG, "Device admin not active — open app to activate")
        }
    }

    companion object {
        const val TAG = "ScreenOffService"
        var instance: ScreenOffService? = null
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
