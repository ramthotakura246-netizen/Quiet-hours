package com.screenoff.app

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {

    private lateinit var dpm: DevicePolicyManager
    private lateinit var adminComponent: ComponentName
    private val REQUEST_ENABLE_ADMIN = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        adminComponent = ComponentName(this, ScreenOffAdminReceiver::class.java)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                SetupScreen()
            }
        }
    }

    @Composable
    fun SetupScreen() {
        var hasOverlay by remember { mutableStateOf(Settings.canDrawOverlays(this)) }
        var hasAdmin by remember { mutableStateOf(dpm.isAdminActive(adminComponent)) }
        var serviceRunning by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            hasOverlay = Settings.canDrawOverlays(this@MainActivity)
            hasAdmin = dpm.isAdminActive(adminComponent)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF121212))
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Spacer(Modifier.height(16.dp))

            Text(
                "Double-Click Screen Off",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                "Double-click the top edge of your screen to turn it off instantly.",
                fontSize = 14.sp,
                color = Color(0xFFAAAAAA)
            )

            Divider(color = Color(0xFF333333))

            // Step 1: Overlay Permission
            PermissionCard(
                step = "1",
                title = "Overlay Permission",
                description = "Needed to detect taps in the top zone over all apps.",
                granted = hasOverlay,
                buttonText = "Grant Overlay",
                onClick = {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                }
            )

            // Step 2: Device Admin
            PermissionCard(
                step = "2",
                title = "Device Administrator",
                description = "Required to lock the screen programmatically.",
                granted = hasAdmin,
                buttonText = "Activate Admin",
                onClick = {
                    val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                        putExtra(
                            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                            "Needed to lock the screen on double-click."
                        )
                    }
                    startActivityForResult(intent, REQUEST_ENABLE_ADMIN)
                }
            )

            // Step 3: Start / Stop Service
            val allReady = hasOverlay && hasAdmin
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "3",
                            color = Color(0xFF6C63FF),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            modifier = Modifier
                                .border(2.dp, Color(0xFF6C63FF), RoundedCornerShape(20.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Text("Enable Feature", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    }
                    Text("Start the overlay service to activate double-click screen-off.", color = Color(0xFFAAAAAA), fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                if (!allReady) {
                                    Toast.makeText(this@MainActivity, "Complete steps 1 & 2 first", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                                serviceRunning = true
                                Toast.makeText(this@MainActivity, "✓ Screen-off active!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C63FF)),
                            enabled = !serviceRunning,
                            shape = RoundedCornerShape(10.dp)
                        ) { Text("Start") }
                        OutlinedButton(
                            onClick = {
                                stopService(Intent(this@MainActivity, OverlayService::class.java))
                                serviceRunning = false
                                Toast.makeText(this@MainActivity, "Service stopped", Toast.LENGTH_SHORT).show()
                            },
                            enabled = serviceRunning,
                            shape = RoundedCornerShape(10.dp)
                        ) { Text("Stop", color = Color.White) }
                    }
                }
            }

            Spacer(Modifier.weight(1f))
            Text(
                "💡 Tip: Double-click anywhere in the top ~8% of your screen (the notification bar area) to lock.",
                fontSize = 12.sp,
                color = Color(0xFF666666)
            )
        }
    }

    @Composable
    fun PermissionCard(
        step: String,
        title: String,
        description: String,
        granted: Boolean,
        buttonText: String,
        onClick: () -> Unit
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Text(
                        step,
                        color = if (granted) Color(0xFF4CAF50) else Color(0xFF6C63FF),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        modifier = Modifier
                            .border(
                                2.dp,
                                if (granted) Color(0xFF4CAF50) else Color(0xFF6C63FF),
                                RoundedCornerShape(20.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            if (granted) {
                                Spacer(Modifier.width(6.dp))
                                Text("✓", color = Color(0xFF4CAF50), fontSize = 14.sp)
                            }
                        }
                        Text(description, color = Color(0xFFAAAAAA), fontSize = 12.sp)
                    }
                }
                if (!granted) {
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = onClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C63FF)),
                        shape = RoundedCornerShape(10.dp)
                    ) { Text(buttonText, fontSize = 12.sp) }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh permission states when returning from settings
    }
}
