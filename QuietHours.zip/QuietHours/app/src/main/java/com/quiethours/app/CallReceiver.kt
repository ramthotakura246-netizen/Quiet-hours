package com.quiethours.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

class CallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // Only care about phone state changes
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        // Only act when a call is ringing
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return

        // Check if Quiet Hours is enabled
        val prefs = context.getSharedPreferences(
            QuietTileService.PREFS_NAME,
            Context.MODE_PRIVATE
        )
        val isEnabled = prefs.getBoolean(QuietTileService.KEY_ENABLED, false)
        if (!isEnabled) return

        // Silently reject the call
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ANSWER_PHONE_CALLS
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            val telecomManager =
                context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            telecomManager.endCall()
            // Call will appear as missed call in the log — exactly like Lumia Quiet Hours
        }
    }
}
