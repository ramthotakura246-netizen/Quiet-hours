package com.expensetracker.data.dao

import androidx.room.*
import com.expensetracker.data.entities.Account
import com.expensetracker.data.entities.Budget
import com.expensetracker.data.entities.Category
import com.expensetracker.data.entities.Transaction
import com.expensetracker.data.entities.TransactionType
import kotlinx.coroutines.flow.Flow

// ── AccountDao ───────────────────────────────────────────────────────────────

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts WHERE isActive = 1 ORDER BY name ASC")
    fun getAllAccounts(): Flow<List<Account>>

    @Query("SELECT * FROM accounts WHERE id = :id")
    suspend fun getById(id: Int): Account?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(account: Account): Long

    @Update
    suspend fun update(account: Account)

    @Query("UPDATE accounts SET balance = :balance WHERE id = :id")
    suspend fun updateBalance(id: Int, balance: Double)

    @Delete
    suspend fun delete(account: Account)
}

// ── CategoryDao ──────────────────────────────────────────────────────────────

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY name ASC")
    fun getAllCategories(): Flow<List<Category>>

    @Query("SELECT * FROM categories WHERE id = :id")
    suspend fun getById(id: Int): Category?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: Category): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(categories: List<Category>)

    @Update
    suspend fun update(category: Category)

    @Delete
    suspend fun delete(category: Category)
}

// ── TransactionDao ───────────────────────────────────────────────────────────

@Dao
interface TransactionDao {

    @Query("""
        SELECT * FROM transactions
        WHERE strftime('%Y-%m', date/1000, 'unixepoch', 'localtime') = :monthYear
        ORDER BY date DESC
    """)
    fun getByMonth(monthYear: String): Flow<List<Transaction>>

    @Query("""
        SELECT * FROM transactions
        WHERE accountId = :accountId
        AND strftime('%Y-%m', date/1000, 'unixepoch', 'localtime') = :monthYear
        ORDER BY date DESC
    """)
    fun getByAccountAndMonth(accountId: Int, monthYear: String): Flow<List<Transaction>>

    @Query("""
        SELECT * FROM transactions
        WHERE (description LIKE '%' || :q || '%' OR merchant LIKE '%' || :q || '%')
        ORDER BY date DESC LIMIT 100
    """)
    fun search(q: String): Flow<List<Transaction>>

    @Query("""
        SELECT SUM(amount) FROM transactions
        WHERE type = 'DEBIT' AND isTransfer = 0
        AND strftime('%Y-%m', date/1000, 'unixepoch', 'localtime') = :monthYear
    """)
    fun getTotalSpentInMonth(monthYear: String): Flow<Double?>

    @Query("""
        SELECT SUM(amount) FROM transactions
        WHERE categoryId = :categoryId AND type = 'DEBIT' AND isTransfer = 0
        AND strftime('%Y-%m', date/1000, 'unixepoch', 'localtime') = :monthYear
    """)
    fun getSpentByCategoryAndMonth(categoryId: Int, monthYear: String): Flow<Double?>

    @Query("""
        SELECT SUM(amount) FROM transactions
        WHERE accountId = :accountId AND type = 'DEBIT'
        AND strftime('%Y-%m', date/1000, 'unixepoch', 'localtime') = :monthYear
    """)
    fun getSpentByAccountAndMonth(accountId: Int, monthYear: String): Flow<Double?>

    @Query("SELECT * FROM transactions WHERE reference = :ref LIMIT 1")
    suspend fun findByReference(ref: String): Transaction?

    @Query("SELECT * FROM transactions ORDER BY date DESC LIMIT :limit")
    fun getRecent(limit: Int = 50): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions ORDER BY date DESC")
    suspend fun getAllForExport(): List<Transaction>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transaction: Transaction): Long

    @Update
    suspend fun update(transaction: Transaction)

    @Delete
    suspend fun delete(transaction: Transaction)
}

// ── BudgetDao ────────────────────────────────────────────────────────────────

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budgets WHERE monthYear = :monthYear")
    fun getByMonth(monthYear: String): Flow<List<Budget>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(budget: Budget)

    @Update
    suspend fun update(budget: Budget)

    @Delete
    suspend fun delete(budget: Budget)
}
