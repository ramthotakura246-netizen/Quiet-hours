package com.expensetracker.util

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "settings")

object PinManager {
    private val PIN_KEY = stringPreferencesKey("app_pin")

    fun getPin(context: Context): Flow<String?> =
        context.dataStore.data.map { it[PIN_KEY] }

    suspend fun setPin(context: Context, pin: String) {
        context.dataStore.edit { it[PIN_KEY] = pin }
    }

    suspend fun clearPin(context: Context) {
        context.dataStore.edit { it.remove(PIN_KEY) }
    }
}
