package com.expensetracker.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.expensetracker.data.entities.*
import com.expensetracker.ui.theme.*
import com.expensetracker.viewmodel.MainViewModel
import java.text.NumberFormat
import java.util.Locale

// ── ACCOUNTS SCREEN ──────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsScreen(vm: MainViewModel) {
    val accounts by vm.accounts.collectAsState()
    var showAdd  by remember { mutableStateOf(false) }
    val fmt      = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    Scaffold(
        containerColor = Black,
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }, containerColor = White,
                contentColor = Black, shape = RoundedCornerShape(0.dp)) {
                Icon(Icons.Default.Add, "Add Account")
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).background(Black)) {
            Box(Modifier.fillMaxWidth().background(Surface1).padding(20.dp)) {
                Text("ACCOUNTS", style = MaterialTheme.typography.headlineMedium.copy(letterSpacing = 3.sp), color = White)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(1.dp), modifier = Modifier.padding(20.dp)) {
                items(accounts) { acc ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape    = RoundedCornerShape(0.dp),
                        colors   = CardDefaults.cardColors(containerColor = Surface1),
                        border   = BorderStroke(1.dp, Border)
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(12.dp).background(
                                    try { Color(android.graphics.Color.parseColor(acc.color)) }
                                    catch (e: Exception) { GreenAccent }
                                ))
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(acc.name.uppercase(), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = White)
                                    Text(acc.type.name.replace("_", " "), style = MaterialTheme.typography.labelSmall, color = DimText)
                                    if (acc.cardLastFour.isNotBlank())
                                        Text("···· ${acc.cardLastFour}", style = MaterialTheme.typography.labelSmall, color = DimText)
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(fmt.format(acc.balance), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = GreenAccent)
                                Text("BALANCE", style = MaterialTheme.typography.labelSmall, color = DimText)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) AddAccountSheet(vm) { showAdd = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAccountSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    var name         by remember { mutableStateOf("") }
    var balance      by remember { mutableStateOf("") }
    var bankCode     by remember { mutableStateOf("") }
    var cardLastFour by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(AccountType.SAVINGS) }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Surface1,
        shape = RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp)) {
        Column(Modifier.fillMaxWidth().padding(20.dp).verticalScroll(rememberScrollState())) {
            Text("ADD ACCOUNT", style = MaterialTheme.typography.headlineMedium.copy(letterSpacing = 3.sp), color = White)
            Spacer(Modifier.height(16.dp))
            MonoTextField("ACCOUNT NAME", name) { name = it }
            Spacer(Modifier.height(8.dp))
            MonoTextField("OPENING BALANCE", balance) { balance = it }
            Spacer(Modifier.height(8.dp))
            MonoTextField("BANK CODE (e.g. HDFC, SBI)", bankCode) { bankCode = it }
            Spacer(Modifier.height(8.dp))
            MonoTextField("CARD LAST 4 DIGITS (optional)", cardLastFour) { cardLastFour = it }
            Spacer(Modifier.height(12.dp))
            Text("TYPE", style = MaterialTheme.typography.labelSmall, color = DimText)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AccountType.values().forEach { type ->
                    FilterChip(selected = selectedType == type, onClick = { selectedType = type },
                        label = { Text(type.name.replace("_"," "), style = MaterialTheme.typography.labelSmall) },
                        shape = RoundedCornerShape(0.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = White, selectedLabelColor = Black, labelColor = DimText))
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                if (name.isBlank()) return@Button
                vm.addAccount(Account(
                    name         = name,
                    type         = selectedType,
                    balance      = balance.toDoubleOrNull() ?: 0.0,
                    bankCode     = bankCode.uppercase(),
                    cardLastFour = cardLastFour
                ))
                onDismiss()
            }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(0.dp),
               colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black)) {
                Text("SAVE ACCOUNT", style = MaterialTheme.typography.labelSmall.copy(fontSize = 13.sp))
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}

// ── BUDGET SCREEN ─────────────────────────────────────────────────────────────

@Composable
fun BudgetScreen(vm: MainViewModel) {
    val budgets    by vm.budgets.collectAsState()
    val categories by vm.categories.collectAsState()
    val monthYear  by vm.monthYear.collectAsState()
    val fmt        = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    var showAdd    by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(Black)) {
        Box(Modifier.fillMaxWidth().background(Surface1).padding(20.dp)) {
            Text("BUDGETS", style = MaterialTheme.typography.headlineMedium.copy(letterSpacing = 3.sp), color = White)
        }
        Text("● ${MainViewModel.formatMonth(monthYear).uppercase()}",
            style = MaterialTheme.typography.labelSmall, color = DimText,
            modifier = Modifier.padding(20.dp, 12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(1.dp),
            modifier = Modifier.padding(horizontal = 20.dp)) {
            items(budgets) { budget ->
                val catSpend by vm.categorySpend(budget.categoryId ?: -1).collectAsState(initial = null)
                val spent    = catSpend ?: 0.0
                val pct      = if (budget.limitAmount > 0) (spent / budget.limitAmount).coerceIn(0.0, 1.0) else 0.0
                val catName  = if (budget.categoryId == null) "Overall" else vm.categoryName(budget.categoryId)
                val catIcon  = if (budget.categoryId == null) "💰" else vm.categoryIcon(budget.categoryId)
                val isOver   = spent >= budget.limitAmount * budget.alertAt

                Card(Modifier.fillMaxWidth(), RoundedCornerShape(0.dp),
                    CardDefaults.cardColors(containerColor = Surface1), BorderStroke(1.dp, if (isOver) NothingRed else Border)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                            Text("$catIcon ${catName.uppercase()}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = White)
                            Text("${fmt.format(spent)} / ${fmt.format(budget.limitAmount)}", style = MaterialTheme.typography.bodyMedium, color = if (isOver) NothingRed else White)
                        }
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress  = { pct.toFloat() },
                            modifier  = Modifier.fillMaxWidth().height(3.dp),
                            color     = if (isOver) NothingRed else GreenAccent,
                            trackColor= Border
                        )
                        if (isOver) {
                            Spacer(Modifier.height(4.dp))
                            Text("⚠ ALERT: ${(pct * 100).toInt()}% SPENT",
                                style = MaterialTheme.typography.labelSmall, color = NothingRed)
                        }
                    }
                }
            }
            item {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth(),
                    shape  = RoundedCornerShape(0.dp),
                    border = BorderStroke(1.dp, Border)) {
                    Text("+ ADD BUDGET", style = MaterialTheme.typography.labelSmall, color = DimText)
                }
                Spacer(Modifier.height(80.dp))
            }
        }
    }

    if (showAdd) AddBudgetSheet(vm, categories, monthYear) { showAdd = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddBudgetSheet(vm: MainViewModel, categories: List<Category>, monthYear: String, onDismiss: () -> Unit) {
    var limit       by remember { mutableStateOf("") }
    var selectedCat by remember { mutableStateOf<Category?>(null) }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Surface1,
        shape = RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp)) {
        Column(Modifier.fillMaxWidth().padding(20.dp)) {
            Text("ADD BUDGET", style = MaterialTheme.typography.headlineMedium.copy(letterSpacing = 3.sp), color = White)
            Spacer(Modifier.height(16.dp))
            MonoTextField("LIMIT AMOUNT (₹)", limit) { limit = it }
            Spacer(Modifier.height(12.dp))
            Text("CATEGORY (leave blank for overall)", style = MaterialTheme.typography.labelSmall, color = DimText)
            Spacer(Modifier.height(6.dp))
            var catExpanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = it }) {
                OutlinedTextField(
                    value = selectedCat?.let { "${it.icon} ${it.name}" } ?: "OVERALL",
                    onValueChange = {}, readOnly = true,
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    colors = monoTextFieldColors(), shape = RoundedCornerShape(0.dp),
                    textStyle = MaterialTheme.typography.bodyMedium
                )
                ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false },
                    modifier = Modifier.background(Surface2)) {
                    DropdownMenuItem(text = { Text("OVERALL", style = MaterialTheme.typography.bodyMedium, color = White) },
                        onClick = { selectedCat = null; catExpanded = false })
                    categories.forEach { cat ->
                        DropdownMenuItem(text = { Text("${cat.icon} ${cat.name.uppercase()}", style = MaterialTheme.typography.bodyMedium, color = White) },
                            onClick = { selectedCat = cat; catExpanded = false })
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                val amt = limit.toDoubleOrNull() ?: return@Button
                vm.addBudget(Budget(categoryId = selectedCat?.id, monthYear = monthYear, limitAmount = amt))
                onDismiss()
            }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(0.dp),
               colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black)) {
                Text("SAVE BUDGET", style = MaterialTheme.typography.labelSmall.copy(fontSize = 13.sp))
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}

// ── REPORTS SCREEN ────────────────────────────────────────────────────────────

@Composable
fun ReportsScreen(vm: MainViewModel) {
    val transactions by vm.monthTransactions.collectAsState()
    val categories   by vm.categories.collectAsState()
    val monthYear    by vm.monthYear.collectAsState()
    val fmt          = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    // Category breakdown
    val catTotals = transactions
        .filter { !it.isTransfer && it.type == TransactionType.DEBIT }
        .groupBy { it.categoryId }
        .mapValues { (_, txs) -> txs.sumOf { it.amount } }
        .entries.sortedByDescending { it.value }

    val grandTotal = catTotals.sumOf { it.value }.let { if (it == 0.0) 1.0 else it }

    Column(Modifier.fillMaxSize().background(Black).verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth().background(Surface1).padding(20.dp)) {
            Text("REPORTS", style = MaterialTheme.typography.headlineMedium.copy(letterSpacing = 3.sp), color = White)
        }
        Text("● ${MainViewModel.formatMonth(monthYear).uppercase()} · CATEGORY BREAKDOWN",
            style = MaterialTheme.typography.labelSmall, color = DimText,
            modifier = Modifier.padding(20.dp, 14.dp, 20.dp, 8.dp))

        catTotals.forEach { (catId, amount) ->
            val cat  = categories.find { it.id == catId }
            val pct  = (amount / grandTotal * 100).toInt()
            Card(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 2.dp),
                RoundedCornerShape(0.dp), CardDefaults.cardColors(containerColor = Surface1), BorderStroke(1.dp, Border)) {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Text("${cat?.icon ?: "📂"} ${(cat?.name ?: "UNKNOWN").uppercase()}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = White)
                        Text(fmt.format(amount), style = MaterialTheme.typography.bodyMedium, color = White)
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        LinearProgressIndicator(
                            progress  = { pct / 100f },
                            modifier  = Modifier.weight(1f).height(3.dp),
                            color     = try { Color(android.graphics.Color.parseColor(cat?.color ?: "#666")) }
                                        catch (e: Exception) { DimText },
                            trackColor= Border
                        )
                        Spacer(Modifier.width(10.dp))
                        Text("$pct%", style = MaterialTheme.typography.labelSmall, color = DimText)
                    }
                }
            }
        }
        Spacer(Modifier.height(80.dp))
    }
}
