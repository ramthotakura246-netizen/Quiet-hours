package com.expensetracker.worker

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.expensetracker.data.AppDatabase
import com.expensetracker.sms.SmsParser
import com.expensetracker.sms.SmsReceiver

/**
 * Reads the SMS inbox on first run (or periodic sync) to catch any
 * bank messages that arrived before the app was installed or while
 * the BroadcastReceiver was sleeping.
 */
class SmsSyncWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val context = applicationContext
        val db      = AppDatabase.getInstance(context)

        val cursor = context.contentResolver.query(
            Uri.parse("content://sms/inbox"),
            arrayOf("address", "body", "date"),
            null, null,
            "date DESC"
        ) ?: return Result.success()

        var processed = 0
        cursor.use {
            val addrIdx = it.getColumnIndex("address")
            val bodyIdx = it.getColumnIndex("body")
            while (it.moveToNext() && processed < 500) {
                val sender = it.getString(addrIdx) ?: continue
                val body   = it.getString(bodyIdx)  ?: continue
                val parsed = SmsParser.parse(body, sender) ?: continue
                SmsReceiver.processParsedSms(context, db, parsed, sender)
                processed++
            }
        }

        Log.d("SmsSyncWorker", "Processed $processed SMS messages")
        return Result.success()
    }
}
