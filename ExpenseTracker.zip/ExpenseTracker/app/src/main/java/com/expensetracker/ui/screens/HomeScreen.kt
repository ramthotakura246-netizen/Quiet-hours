package com.expensetracker.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.expensetracker.ui.theme.*
import com.expensetracker.viewmodel.MainViewModel
import com.expensetracker.viewmodel.MainViewModel.Companion.formatMonth
import java.text.NumberFormat
import java.util.Locale

@Composable
fun HomeScreen(vm: MainViewModel, navController: NavController) {
    val monthYear    by vm.monthYear.collectAsState()
    val accounts     by vm.accounts.collectAsState()
    val totalSpent   by vm.totalSpent.collectAsState()
    val recentTx     by vm.recentTx.collectAsState()

    val fmt = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black)
            .verticalScroll(rememberScrollState())
    ) {
        // ── Header ──────────────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface1)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text  = "PAY●TRACK",
                style = MaterialTheme.typography.headlineMedium.copy(letterSpacing = 4.sp),
                color = White
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(6.dp).background(NothingRed, shape = RoundedCornerShape(50)))
                Spacer(Modifier.width(5.dp))
                Text("LIVE", style = MaterialTheme.typography.labelSmall, color = DimText)
            }
        }

        // ── Month Switcher ───────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { vm.prevMonth() }) {
                Icon(Icons.Default.ChevronLeft, contentDescription = "Prev", tint = White)
            }
            Text(
                text  = formatMonth(monthYear).uppercase(),
                style = MaterialTheme.typography.bodyMedium.copy(letterSpacing = 2.sp),
                color = White
            )
            IconButton(onClick = { vm.nextMonth() }) {
                Icon(Icons.Default.ChevronRight, contentDescription = "Next", tint = White)
            }
        }

        // ── Total Spend Card ─────────────────────────────────────────────────
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            shape  = RoundedCornerShape(0.dp),
            colors = CardDefaults.cardColors(containerColor = Surface1),
            border = BorderStroke(1.dp, Border)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("TOTAL SPENT THIS MONTH",
                    style = MaterialTheme.typography.labelSmall, color = DimText)
                Spacer(Modifier.height(6.dp))
                Text(
                    text  = fmt.format(totalSpent ?: 0.0),
                    style = MaterialTheme.typography.displayLarge,
                    color = NothingRed
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // ── Per Account Cards ────────────────────────────────────────────────
        Text(
            text     = "● SPEND BY ACCOUNT",
            style    = MaterialTheme.typography.labelSmall,
            color    = DimText,
            modifier = Modifier.padding(start = 20.dp, bottom = 8.dp)
        )

        accounts.forEach { account ->
            val accountSpend by vm.accountSpend(account.id).collectAsState(initial = null)
            val spent  = accountSpend ?: 0.0
            val total  = (totalSpent ?: 1.0).let { if (it == 0.0) 1.0 else it }
            val pct    = if (spent > 0) ((spent / total) * 100).toInt() else 0

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 3.dp)
                    .clickable { navController.navigate("transactions") },
                shape  = RoundedCornerShape(0.dp),
                colors = CardDefaults.cardColors(containerColor = Surface1),
                border = BorderStroke(1.dp, Border)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(account.name.uppercase(),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = White)
                        Text(account.type.name.replace("_", " "),
                            style = MaterialTheme.typography.labelSmall, color = DimText)
                        Spacer(Modifier.height(8.dp))
                        // Progress bar
                        LinearProgressIndicator(
                            progress  = { (pct / 100f).coerceIn(0f, 1f) },
                            modifier  = Modifier.fillMaxWidth().height(2.dp),
                            color     = try { Color(android.graphics.Color.parseColor(account.color)) } catch (e: Exception) { GreenAccent },
                            trackColor= Border
                        )
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text  = fmt.format(spent),
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = White
                        )
                        Text("$pct% of total",
                            style = MaterialTheme.typography.labelSmall, color = DimText)
                        Text("Bal: ${fmt.format(account.balance)}",
                            style = MaterialTheme.typography.labelSmall, color = DimText)
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // ── Recent Transactions ──────────────────────────────────────────────
        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("● RECENT", style = MaterialTheme.typography.labelSmall, color = DimText)
        }

        recentTx.take(10).forEach { tx ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 2.dp),
                shape  = RoundedCornerShape(0.dp),
                colors = CardDefaults.cardColors(containerColor = Surface1),
                border = BorderStroke(1.dp, Border)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            text  = tx.merchant.ifBlank { tx.description.take(30) }.uppercase(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = White
                        )
                        Text(
                            text  = "${vm.categoryIcon(tx.categoryId)} ${vm.categoryName(tx.categoryId)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = DimText
                        )
                    }
                    Text(
                        text  = "${if (tx.type.name == "CREDIT") "+" else "-"}${fmt.format(tx.amount)}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (tx.type.name == "CREDIT") GreenAccent else NothingRed
                    )
                }
            }
        }

        Spacer(Modifier.height(80.dp))
    }
}
