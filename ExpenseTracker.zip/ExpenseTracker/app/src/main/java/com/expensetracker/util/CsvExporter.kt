package com.expensetracker.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.expensetracker.data.entities.Transaction
import com.expensetracker.data.entities.TransactionType
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object CsvExporter {

    fun export(context: Context, transactions: List<Transaction>,
               categoryName: (Int?) -> String, accountName: (Int?) -> String) {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val sb  = StringBuilder()
        sb.appendLine("Date,Type,Amount,Account,Category,Merchant,Description,Reference")

        transactions.forEach { tx ->
            sb.appendLine(
                listOf(
                    sdf.format(Date(tx.date)),
                    tx.type.name,
                    tx.amount.toString(),
                    accountName(tx.accountId),
                    categoryName(tx.categoryId),
                    tx.merchant.replace(",", " "),
                    tx.description.take(80).replace(",", " ").replace("\n", " "),
                    tx.reference
                ).joinToString(",")
            )
        }

        val fileName = "expenses_${SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())}.csv"
        val file     = File(context.cacheDir, fileName)
        file.writeText(sb.toString())

        val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val intent   = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Export CSV").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }
}
