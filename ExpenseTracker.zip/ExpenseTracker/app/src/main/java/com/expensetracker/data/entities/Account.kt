package com.expensetracker.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AccountType { SAVINGS, CURRENT, CREDIT_CARD, WALLET, CASH, UPI }

@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val type: AccountType,
    val balance: Double = 0.0,
    val cardLastFour: String = "",
    val bankCode: String = "",
    val isActive: Boolean = true,
    val color: String = "#00E5A0"
)
