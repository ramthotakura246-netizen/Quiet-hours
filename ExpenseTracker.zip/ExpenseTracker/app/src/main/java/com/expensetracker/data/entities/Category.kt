package com.expensetracker.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val icon: String,
    val color: String,
    val isDefault: Boolean = false
)

val DEFAULT_CATEGORIES = listOf(
    Category(name = "Food & Dining",     icon = "🍔", color = "#FF6B6B", isDefault = true),
    Category(name = "Transport",          icon = "🚗", color = "#4ECDC4", isDefault = true),
    Category(name = "Shopping",           icon = "🛍️", color = "#45B7D1", isDefault = true),
    Category(name = "Bills & Utilities",  icon = "💡", color = "#96CEB4", isDefault = true),
    Category(name = "Entertainment",      icon = "🎬", color = "#FFEAA7", isDefault = true),
    Category(name = "Health",             icon = "💊", color = "#DDA0DD", isDefault = true),
    Category(name = "Groceries",          icon = "🛒", color = "#98D8C8", isDefault = true),
    Category(name = "Education",          icon = "📚", color = "#F7DC6F", isDefault = true),
    Category(name = "Travel",             icon = "✈️", color = "#85C1E9", isDefault = true),
    Category(name = "Transfer",           icon = "🔄", color = "#BDC3C7", isDefault = true),
    Category(name = "Other",              icon = "📂", color = "#808080", isDefault = true),
)
