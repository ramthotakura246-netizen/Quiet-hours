package com.expensetracker.sms

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.expensetracker.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TransactionNotificationListener : NotificationListenerService() {

    private val PAYMENT_APPS = setOf(
        "com.google.android.apps.nbu.paisa.user",  // Google Pay
        "com.phonepe.app",                           // PhonePe
        "net.one97.paytm",                           // Paytm
        "com.dreamplug.androidapp",                  // CRED
        "in.amazon.mShop.android.shopping",          // Amazon Pay
        "com.freecharge.android",                    // Freecharge
        "com.mobikwik_new",                          // MobiKwik
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg !in PAYMENT_APPS) return

        val extras = sbn.notification.extras
        val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text  = extras.getString(Notification.EXTRA_TEXT)  ?: ""
        val bigText = extras.getString(Notification.EXTRA_BIG_TEXT) ?: text

        val body = "$title $bigText"
        Log.d("NotifListener", "Payment app [$pkg]: $body")

        val parsed = SmsParser.parse(body, pkg) ?: return

        CoroutineScope(Dispatchers.IO).launch {
            SmsReceiver.processParsedSms(
                applicationContext,
                AppDatabase.getInstance(applicationContext),
                parsed,
                pkg
            )
        }
    }
}
