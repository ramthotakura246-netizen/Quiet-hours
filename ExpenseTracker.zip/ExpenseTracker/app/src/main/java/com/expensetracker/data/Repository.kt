package com.expensetracker.data

import com.expensetracker.data.dao.AccountDao
import com.expensetracker.data.dao.BudgetDao
import com.expensetracker.data.dao.CategoryDao
import com.expensetracker.data.dao.TransactionDao
import com.expensetracker.data.entities.*
import kotlinx.coroutines.flow.Flow

class Repository(
    private val accountDao: AccountDao,
    private val categoryDao: CategoryDao,
    private val transactionDao: TransactionDao,
    private val budgetDao: BudgetDao
) {
    // Accounts
    val allAccounts: Flow<List<Account>> = accountDao.getAllAccounts()
    suspend fun insertAccount(a: Account) = accountDao.insert(a)
    suspend fun updateAccount(a: Account) = accountDao.update(a)
    suspend fun deleteAccount(a: Account) = accountDao.delete(a)
    suspend fun updateBalance(id: Int, balance: Double) = accountDao.updateBalance(id, balance)

    // Categories
    val allCategories: Flow<List<Category>> = categoryDao.getAllCategories()
    suspend fun insertCategory(c: Category) = categoryDao.insert(c)
    suspend fun updateCategory(c: Category) = categoryDao.update(c)

    // Transactions
    fun getByMonth(monthYear: String)          = transactionDao.getByMonth(monthYear)
    fun getByAccountAndMonth(id: Int, m: String) = transactionDao.getByAccountAndMonth(id, m)
    fun getRecent(limit: Int = 50)             = transactionDao.getRecent(limit)
    fun search(q: String)                      = transactionDao.search(q)
    suspend fun getAllForExport()               = transactionDao.getAllForExport()
    suspend fun insertTransaction(t: Transaction) = transactionDao.insert(t)
    suspend fun updateTransaction(t: Transaction) = transactionDao.update(t)
    suspend fun deleteTransaction(t: Transaction) = transactionDao.delete(t)

    // Summary
    fun getTotalSpent(monthYear: String) = transactionDao.getTotalSpentInMonth(monthYear)
    fun getCategorySpend(catId: Int, monthYear: String) =
        transactionDao.getSpentByCategoryAndMonth(catId, monthYear)
    fun getAccountSpend(accId: Int, monthYear: String) =
        transactionDao.getSpentByAccountAndMonth(accId, monthYear)

    // Budgets
    fun getBudgets(monthYear: String) = budgetDao.getByMonth(monthYear)
    suspend fun insertBudget(b: Budget) = budgetDao.insert(b)
    suspend fun updateBudget(b: Budget) = budgetDao.update(b)
    suspend fun deleteBudget(b: Budget) = budgetDao.delete(b)
}
