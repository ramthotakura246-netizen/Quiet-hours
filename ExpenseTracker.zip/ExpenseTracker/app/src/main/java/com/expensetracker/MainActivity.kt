package com.expensetracker

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.*
import com.expensetracker.ui.screens.*
import com.expensetracker.ui.theme.ExpenseTrackerTheme
import com.expensetracker.viewmodel.MainViewModel
import com.expensetracker.worker.scheduleSmsSync

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* handle result */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestRequiredPermissions()
        scheduleSmsSync(this)

        setContent {
            ExpenseTrackerTheme {
                AppNavigation(viewModel)
            }
        }
    }

    private fun requestRequiredPermissions() {
        val perms = mutableListOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(perms.toTypedArray())

        // Notification listener requires manual enable by user
        if (!isNotificationListenerEnabled()) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val cn = "${packageName}/.sms.TransactionNotificationListener"
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat?.contains(cn) == true
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val navController = rememberNavController()

    val items = listOf(
        Triple("home",         "Home",         Icons.Default.Home),
        Triple("transactions", "Transactions", Icons.Default.List),
        Triple("accounts",     "Accounts",     Icons.Default.AccountBalance),
        Triple("budgets",      "Budgets",      Icons.Default.PieChart),
        Triple("reports",      "Reports",      Icons.Default.BarChart),
    )

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = com.expensetracker.ui.theme.Surface1) {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDest = navBackStackEntry?.destination
                items.forEach { (route, label, icon) ->
                    NavigationBarItem(
                        icon     = { Icon(icon, contentDescription = label) },
                        label    = { Text(label, style = MaterialTheme.typography.labelSmall) },
                        selected = currentDest?.hierarchy?.any { it.route == route } == true,
                        onClick  = {
                            navController.navigate(route) {
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState    = true
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor   = com.expensetracker.ui.theme.White,
                            unselectedIconColor = com.expensetracker.ui.theme.DimText,
                            indicatorColor      = com.expensetracker.ui.theme.Border
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController    = navController,
            startDestination = "home",
            modifier         = Modifier.padding(innerPadding)
        ) {
            composable("home")         { HomeScreen(viewModel, navController) }
            composable("transactions") { TransactionsScreen(viewModel) }
            composable("accounts")     { AccountsScreen(viewModel) }
            composable("budgets")      { BudgetScreen(viewModel) }
            composable("reports")      { ReportsScreen(viewModel) }
        }
    }
}
