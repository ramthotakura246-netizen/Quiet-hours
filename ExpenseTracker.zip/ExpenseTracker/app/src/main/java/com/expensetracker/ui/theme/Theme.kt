package com.expensetracker.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Nothing OS color palette
val Black      = Color(0xFF000000)
val Surface1   = Color(0xFF0D0D0D)
val Surface2   = Color(0xFF141414)
val Border     = Color(0xFF1F1F1F)
val NothingRed = Color(0xFFFF0000)
val White      = Color(0xFFFFFFFF)
val DimText    = Color(0xFF666666)
val GreenAccent= Color(0xFF00E5A0)

private val DarkColorScheme = darkColorScheme(
    primary          = White,
    onPrimary        = Black,
    secondary        = NothingRed,
    onSecondary      = White,
    background       = Black,
    onBackground     = White,
    surface          = Surface1,
    onSurface        = White,
    surfaceVariant   = Surface2,
    outline          = Border,
    error            = NothingRed,
)

val AppTypography = Typography(
    displayLarge  = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,   fontSize = 36.sp),
    headlineMedium= TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,   fontSize = 20.sp),
    titleMedium   = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, letterSpacing = 0.5.sp),
    bodyMedium    = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Normal, fontSize = 13.sp),
    labelSmall    = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Normal, fontSize = 10.sp, letterSpacing = 2.sp),
)

@Composable
fun ExpenseTrackerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = AppTypography,
        content     = content
    )
}
