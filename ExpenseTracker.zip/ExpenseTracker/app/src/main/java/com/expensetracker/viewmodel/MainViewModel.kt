package com.expensetracker.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.expensetracker.data.AppDatabase
import com.expensetracker.data.Repository
import com.expensetracker.data.entities.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db   = AppDatabase.getInstance(application)
    val repository   = Repository(db.accountDao(), db.categoryDao(), db.transactionDao(), db.budgetDao())

    // Current selected month (default: this month)
    private val _monthYear = MutableStateFlow(currentMonthYear())
    val monthYear: StateFlow<String> = _monthYear

    val accounts   = repository.allAccounts.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val categories = repository.allCategories.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val recentTx   = repository.getRecent(50).stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val monthTransactions = _monthYear.flatMapLatest { m ->
        repository.getByMonth(m)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val totalSpent = _monthYear.flatMapLatest { m ->
        repository.getTotalSpent(m)
    }.stateIn(viewModelScope, SharingStarted.Lazily, null)

    // Account-wise spend for headline screen
    fun accountSpend(accountId: Int): Flow<Double?> =
        _monthYear.flatMapLatest { m -> repository.getAccountSpend(accountId, m) }

    // Category spend for budget screen
    fun categorySpend(categoryId: Int): Flow<Double?> =
        _monthYear.flatMapLatest { m -> repository.getCategorySpend(categoryId, m) }

    val budgets = _monthYear.flatMapLatest { m ->
        repository.getBudgets(m)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun setMonth(monthYear: String) { _monthYear.value = monthYear }
    fun prevMonth() { _monthYear.value = offsetMonth(_monthYear.value, -1) }
    fun nextMonth() { _monthYear.value = offsetMonth(_monthYear.value, +1) }

    // ── CRUD ────────────────────────────────────────────────────────────────

    fun addAccount(account: Account)          = viewModelScope.launch { repository.insertAccount(account) }
    fun updateAccount(account: Account)       = viewModelScope.launch { repository.updateAccount(account) }
    fun deleteAccount(account: Account)       = viewModelScope.launch { repository.deleteAccount(account) }

    fun addTransaction(tx: Transaction)       = viewModelScope.launch { repository.insertTransaction(tx) }
    fun updateTransaction(tx: Transaction)    = viewModelScope.launch { repository.updateTransaction(tx) }
    fun deleteTransaction(tx: Transaction)    = viewModelScope.launch { repository.deleteTransaction(tx) }

    fun addBudget(budget: Budget)             = viewModelScope.launch { repository.insertBudget(budget) }
    fun deleteBudget(budget: Budget)          = viewModelScope.launch { repository.deleteBudget(budget) }

    // ── Helpers ──────────────────────────────────────────────────────────────

    fun categoryName(id: Int?): String =
        categories.value.find { it.id == id }?.name ?: "Uncategorized"

    fun categoryIcon(id: Int?): String =
        categories.value.find { it.id == id }?.icon ?: "📂"

    fun accountName(id: Int?): String =
        accounts.value.find { it.id == id }?.name ?: "Unknown"

    companion object {
        fun currentMonthYear(): String =
            SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())

        fun offsetMonth(current: String, offset: Int): String {
            val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
            val cal = Calendar.getInstance()
            cal.time = sdf.parse(current) ?: Date()
            cal.add(Calendar.MONTH, offset)
            return sdf.format(cal.time)
        }

        fun formatMonth(monthYear: String): String {
            return try {
                val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
                val out = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
                out.format(sdf.parse(monthYear) ?: Date())
            } catch (e: Exception) { monthYear }
        }
    }
}
