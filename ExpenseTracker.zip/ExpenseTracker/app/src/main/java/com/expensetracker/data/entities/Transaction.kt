package com.expensetracker.data.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class TransactionType { DEBIT, CREDIT, TRANSFER }
enum class TransactionSource { SMS, NOTIFICATION, MANUAL }

@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(entity = Account::class,  parentColumns = ["id"], childColumns = ["accountId"],   onDelete = ForeignKey.SET_NULL),
        ForeignKey(entity = Account::class,  parentColumns = ["id"], childColumns = ["toAccountId"], onDelete = ForeignKey.SET_NULL),
        ForeignKey(entity = Category::class, parentColumns = ["id"], childColumns = ["categoryId"],  onDelete = ForeignKey.SET_NULL)
    ],
    indices = [Index("accountId"), Index("toAccountId"), Index("categoryId"), Index("reference")]
)
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val amount: Double,
    val type: TransactionType,
    val accountId: Int?,
    val toAccountId: Int? = null,       // transfers only
    val categoryId: Int?,
    val merchant: String = "",
    val description: String = "",
    val date: Long = System.currentTimeMillis(),
    val source: TransactionSource = TransactionSource.MANUAL,
    val rawSms: String = "",
    val isTransfer: Boolean = false,    // exclude from expense totals
    val balanceAfter: Double? = null,
    val reference: String = ""          // UPI ref ID for deduplication
)
