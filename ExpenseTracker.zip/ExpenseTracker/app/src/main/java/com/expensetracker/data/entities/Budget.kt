package com.expensetracker.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val categoryId: Int?,       // null = overall monthly budget
    val monthYear: String,      // "2024-06"
    val limitAmount: Double,
    val alertAt: Double = 0.8   // alert when 80% spent
)
