package com.caffeine.tile

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

class CaffeineTileService : TileService() {

    companion object {
        const val PREFS_NAME = "CaffeineTilePrefs"
        const val KEY_ENABLED = "quiet_mode_enabled"
    }

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val isEnabled = prefs.getBoolean(KEY_ENABLED, false)

        // Toggle
        prefs.edit().putBoolean(KEY_ENABLED, !isEnabled).apply()
        refreshTile()

        val message = if (!isEnabled)
            "Quiet Hours ON — Calls silently rejected"
        else
            "Quiet Hours OFF — Calls allowed"

        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun refreshTile() {
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val isEnabled = prefs.getBoolean(KEY_ENABLED, false)

        qsTile?.apply {
            state = if (isEnabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "Quiet Hours"
            contentDescription = if (isEnabled)
                "Quiet Hours enabled - calls blocked"
            else
                "Quiet Hours disabled - calls allowed"
            updateTile()
        }
    }
}
