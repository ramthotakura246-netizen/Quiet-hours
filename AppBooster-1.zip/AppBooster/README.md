# 🚀 AppBooster — Android App

A Nothing Phone 2 optimized app that channels your phone's full CPU and network resources to one single app.

---

## What It Does

- **Kills all background apps** every 15 seconds while boost is active
- **Acquires Wi-Fi High Performance Lock** — prevents Wi-Fi from throttling
- **Acquires CPU Wake Lock** — prevents CPU from sleeping
- **Runs as a Foreground Service** — keeps boosting even when you switch to your target app
- **Live RAM stats** — shows how much memory is freed

---

## How to Build & Install

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- Nothing Phone 2 with USB debugging enabled

### Steps

**1. Open the project**
```
File → Open → Select the AppBooster folder
```

**2. Sync Gradle**
Click "Sync Now" when Android Studio prompts you.

**3. Connect your Nothing Phone 2**
- Enable Developer Options: Settings → About Phone → tap Build Number 7 times
- Enable USB Debugging: Settings → Developer Options → USB Debugging → ON
- Connect via USB cable

**4. Run the app**
Click the green ▶ Play button or press `Shift+F10`

---

## First-Time Setup on Phone

When you open AppBooster for the first time:

1. Tap **"FIX NOW"** if the permission warning appears
2. Grant **Usage Access** to AppBooster (required to read running apps)
3. Allow **Battery Optimization Exemption** (so the service keeps running)

---

## How to Use

1. Tap **SELECT APP** → pick the app you want to boost
2. Tap **🚀 START BOOST**
3. Open your selected app — it now has maximum priority
4. A notification shows AppBooster is actively running
5. Tap **STOP BOOST** when done

---

## Permissions Explained

| Permission | Why It's Needed |
|---|---|
| `KILL_BACKGROUND_PROCESSES` | Clear RAM by killing other apps |
| `FOREGROUND_SERVICE` | Keep boost running while you use your app |
| `PACKAGE_USAGE_STATS` | Read which apps are running |
| `CHANGE_NETWORK_STATE` | Wi-Fi high performance lock |
| `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | Prevent Android from killing the service |

---

## Project Structure

```
AppBooster/
├── app/src/main/
│   ├── java/com/nothing/appbooster/
│   │   ├── MainActivity.kt          ← Main UI + boost controls
│   │   ├── AppPickerActivity.kt     ← App selection screen
│   │   └── BoostService.kt          ← Background boost service
│   ├── res/
│   │   ├── layout/
│   │   │   ├── activity_main.xml
│   │   │   ├── activity_app_picker.xml
│   │   │   └── item_app.xml
│   │   ├── values/
│   │   │   ├── colors.xml           ← Nothing OS dark theme colors
│   │   │   ├── strings.xml
│   │   │   └── themes.xml
│   │   └── drawable/
│   └── AndroidManifest.xml
└── build.gradle
```

---

## Troubleshooting

**App doesn't appear in list** → Only user-installed launchable apps are shown. System apps are hidden.

**Boost stops after a while** → Make sure Battery Optimization is disabled for AppBooster. Go to Settings → Battery → AppBooster → Unrestricted.

**"Usage Access" permission missing** → Go to Settings → Privacy → Permission Manager → Usage Access → AppBooster → Allow.

---

Built for Nothing Phone 2 · Nothing OS 2.x · Android 13/14
