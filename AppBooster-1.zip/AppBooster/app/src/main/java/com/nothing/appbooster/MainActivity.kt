package com.nothing.appbooster

import android.app.ActivityManager
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.nothing.appbooster.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences
    private var isBoostActive = false

    // Replaces deprecated startActivityForResult
    private val pickAppLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val appName = result.data?.getStringExtra("app_name") ?: return@registerForActivityResult
            val pkg = result.data?.getStringExtra("package_name") ?: return@registerForActivityResult
            prefs.edit().putString(KEY_APP_NAME, appName).putString(KEY_PACKAGE, pkg).apply()
            updateSelectedAppUI(appName, pkg)
            if (isBoostActive) stopBoost()
        }
    }

    companion object {
        private const val PREFS_NAME = "AppBoosterPrefs"
        private const val KEY_PACKAGE = "target_package"
        private const val KEY_APP_NAME = "target_app_name"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        binding.btnSelectApp.setOnClickListener {
            pickAppLauncher.launch(Intent(this, AppPickerActivity::class.java))
        }

        binding.btnBoost.setOnClickListener {
            val pkg = prefs.getString(KEY_PACKAGE, null)
            if (pkg == null) {
                Toast.makeText(this, "Please select an app first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!hasUsageStatsPermission()) {
                Toast.makeText(this, "Please grant Usage Access for AppBooster", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                return@setOnClickListener
            }
            if (isBoostActive) stopBoost() else startBoost(pkg)
        }

        binding.btnFixPermissions.setOnClickListener { requestNextPermission() }

        loadSavedApp()
        updateMemoryStats()
        checkPermissions()
    }

    private fun loadSavedApp() {
        val name = prefs.getString(KEY_APP_NAME, null)
        val pkg = prefs.getString(KEY_PACKAGE, null)
        if (name != null && pkg != null) {
            updateSelectedAppUI(name, pkg)
        } else {
            binding.tvSelectedApp.text = "No app selected"
            binding.tvSelectedPackage.text = "Tap below to choose an app"
            binding.ivAppIcon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_app_placeholder))
        }
    }

    private fun updateSelectedAppUI(appName: String, packageName: String) {
        binding.tvSelectedApp.text = appName
        binding.tvSelectedPackage.text = packageName
        try {
            binding.ivAppIcon.setImageDrawable(packageManager.getApplicationIcon(packageName))
        } catch (e: Exception) {
            binding.ivAppIcon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_app_placeholder))
        }
    }

    private fun startBoost(targetPackage: String) {
        isBoostActive = true
        updateBoostUI(true)
        ContextCompat.startForegroundService(this, Intent(this, BoostService::class.java).apply {
            putExtra("target_package", targetPackage)
            putExtra("app_name", prefs.getString(KEY_APP_NAME, "App"))
        })
        requestBatteryOptimizationExemption()
        Toast.makeText(this, "🚀 Boost activated!", Toast.LENGTH_SHORT).show()
    }

    private fun stopBoost() {
        isBoostActive = false
        updateBoostUI(false)
        stopService(Intent(this, BoostService::class.java))
        updateMemoryStats()
        Toast.makeText(this, "Boost stopped — settings restored", Toast.LENGTH_SHORT).show()
    }

    private fun updateBoostUI(active: Boolean) {
        if (active) {
            binding.btnBoost.text = "⬛  STOP BOOST"
            binding.btnBoost.setBackgroundColor(ContextCompat.getColor(this, R.color.boost_stop))
            binding.tvBoostStatus.text = "🟢  BOOST ACTIVE"
            binding.tvBoostStatus.setTextColor(ContextCompat.getColor(this, R.color.boost_active))
            binding.boostRing.visibility = View.VISIBLE
        } else {
            binding.btnBoost.text = "🚀  START BOOST"
            binding.btnBoost.setBackgroundColor(ContextCompat.getColor(this, R.color.boost_start))
            binding.tvBoostStatus.text = "⚪  BOOST INACTIVE"
            binding.tvBoostStatus.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
            binding.boostRing.visibility = View.GONE
        }
    }

    private fun updateMemoryStats() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val availMb = memInfo.availMem / (1024 * 1024)
        val totalMb = memInfo.totalMem / (1024 * 1024)
        val usedPct = ((totalMb - availMb) * 100) / totalMb
        binding.tvMemoryStats.text = "RAM: ${availMb}MB free of ${totalMb}MB (${usedPct}% used)"
    }

    private fun checkPermissions() {
        val hasUsage = hasUsageStatsPermission()
        val hasBattery = isIgnoringBatteryOptimizations()
        if (hasUsage && hasBattery) {
            binding.cardPermissions.visibility = View.GONE
        } else {
            binding.cardPermissions.visibility = View.VISIBLE
            val missing = buildList {
                if (!hasUsage) add("Usage Access")
                if (!hasBattery) add("Battery Unrestricted")
            }
            binding.tvPermissionStatus.text = "Missing: ${missing.joinToString(", ")}"
        }
    }

    private fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    private fun isIgnoringBatteryOptimizations(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun requestBatteryOptimizationExemption() {
        if (!isIgnoringBatteryOptimizations()) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            })
        }
    }

    private fun requestNextPermission() {
        if (!hasUsageStatsPermission()) {
            Toast.makeText(this, "Please grant Usage Access for AppBooster", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        } else {
            requestBatteryOptimizationExemption()
        }
    }

    override fun onResume() {
        super.onResume()
        checkPermissions()
        updateMemoryStats()
    }
}
