package com.nothing.appbooster

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class BoostService : Service() {

    // Cached system services — obtained once, reused every loop tick
    private lateinit var activityManager: ActivityManager
    private lateinit var notificationManager: NotificationManager
    private var targetPackage: String = ""
    private var appName: String = "App"

    // Single supervised scope — cancelled atomically in onDestroy
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    // Track whether we disabled auto-sync so we can restore it on stop
    private var syncWasEnabled = false

    companion object {
        const val CHANNEL_ID = "AppBoosterChannel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.nothing.appbooster.STOP"
    }

    override fun onCreate() {
        super.onCreate()
        activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        targetPackage = intent?.getStringExtra("target_package") ?: run {
            stopSelf()
            return START_NOT_STICKY
        }
        appName = intent.getStringExtra("app_name") ?: "App"

        startForeground(NOTIFICATION_ID, buildNotification("Boosting $appName…"))
        acquireWakeLock()
        acquireWifiLock()
        disableBackgroundSync()
        startBoostLoop()

        return START_STICKY
    }

    private fun startBoostLoop() {
        serviceScope.launch {
            while (isActive) {
                killBackgroundApps()
                val availMb = getAvailableRamMb()
                updateNotification("Boosting $appName · ${availMb}MB RAM free")
                delay(15_000L)
            }
        }
    }

    private fun killBackgroundApps() {
        val processes = activityManager.runningAppProcesses ?: return
        for (process in processes) {
            if (process.importance > ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                for (pkg in process.pkgList) {
                    if (pkg != targetPackage && pkg != packageName) {
                        activityManager.killBackgroundProcesses(pkg)
                    }
                }
            }
        }
    }

    private fun getAvailableRamMb(): Long {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        return memInfo.availMem / (1024 * 1024)
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AppBooster::WakeLock")
        wakeLock?.acquire(60 * 60 * 1000L) // 1 hour max
    }

    private fun acquireWifiLock() {
        // WIFI_MODE_FULL_LOW_LATENCY: preferred over FULL_HIGH_PERF (deprecated in API 29)
        // Works on both Wi-Fi and does no harm on mobile data (simply not acquired)
        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifiLock = wifiManager.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "AppBooster::WifiLock")
        if (wifiLock?.isHeld == false) wifiLock?.acquire()
    }

    /**
     * Disables global background sync while boost is active.
     * This prevents background apps from making network calls on mobile data.
     * We store the previous state so we can restore it exactly on stop.
     *
     * Note: Per-app mobile data restriction requires MANAGE_NETWORK_POLICY
     * (a system-level permission unavailable to 3rd party apps without root).
     * Global sync disable is the best achievable alternative.
     */
    private fun disableBackgroundSync() {
        syncWasEnabled = ContentResolver.getMasterSyncAutomatically()
        if (syncWasEnabled) {
            ContentResolver.setMasterSyncAutomatically(false)
        }
    }

    private fun restoreBackgroundSync() {
        if (syncWasEnabled) {
            ContentResolver.setMasterSyncAutomatically(true)
        }
    }

    private fun updateNotification(text: String) {
        notificationManager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, BoostService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🚀 AppBooster Active")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_boost_notification)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "AppBooster Service",
            NotificationManager.IMPORTANCE_LOW
        )
        notificationManager.createNotificationChannel(channel)
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        if (wifiLock?.isHeld == true) wifiLock?.release()
        restoreBackgroundSync() // Restore mobile data background sync for all apps
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
