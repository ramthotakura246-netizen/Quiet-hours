package com.nothing.appbooster

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.nothing.appbooster.databinding.ActivityAppPickerBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppPickerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppPickerBinding
    private lateinit var adapter: AppListAdapter
    private val activityScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var allApps = emptyList<AppInfo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppPickerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = AppListAdapter { app ->
            setResult(RESULT_OK, Intent().apply {
                putExtra("app_name", app.name)
                putExtra("package_name", app.packageName)
            })
            finish()
        }
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.btnBack.setOnClickListener { finish() }

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { filterApps(s.toString()) }
            override fun afterTextChanged(s: Editable?) {}
        })

        loadApps()
    }

    private fun loadApps() {
        binding.progressBar.visibility = View.VISIBLE
        activityScope.launch {
            val apps = withContext(Dispatchers.IO) {
                val pm = packageManager
                pm.getInstalledApplications(PackageManager.GET_META_DATA)
                    .filter { info ->
                        val isUser = (info.flags and ApplicationInfo.FLAG_SYSTEM) == 0
                        isUser && pm.getLaunchIntentForPackage(info.packageName) != null
                    }
                    .map { info -> AppInfo(pm.getApplicationLabel(info).toString(), info.packageName) }
                    .sortedBy { it.name }
            }
            allApps = apps
            binding.progressBar.visibility = View.GONE
            adapter.submitList(apps)
            binding.tvAppCount.text = "${apps.size} apps"
        }
    }

    private fun filterApps(query: String) {
        val filtered = if (query.isEmpty()) allApps
        else allApps.filter { it.name.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true) }
        adapter.submitList(filtered)
        binding.tvAppCount.text = "${filtered.size} apps"
    }

    override fun onDestroy() {
        super.onDestroy()
        activityScope.cancel()
    }
}

data class AppInfo(val name: String, val packageName: String)

class AppListAdapter(private val onAppClick: (AppInfo) -> Unit) :
    RecyclerView.Adapter<AppListAdapter.ViewHolder>() {

    private var apps = emptyList<AppInfo>()

    fun submitList(newApps: List<AppInfo>) {
        apps = newApps
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(apps[position])
    override fun getItemCount() = apps.size

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val icon: ImageView = view.findViewById(R.id.iv_app_icon)
        private val name: TextView = view.findViewById(R.id.tv_app_name)
        private val pkg: TextView = view.findViewById(R.id.tv_package_name)

        fun bind(app: AppInfo) {
            name.text = app.name
            pkg.text = app.packageName
            try {
                icon.setImageDrawable(itemView.context.packageManager.getApplicationIcon(app.packageName))
            } catch (e: Exception) {
                icon.setImageResource(R.drawable.ic_app_placeholder)
            }
            itemView.setOnClickListener { onAppClick(app) }
        }
    }
}
