package com.expensetracker.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.expensetracker.data.entities.*
import com.expensetracker.ui.theme.*
import com.expensetracker.viewmodel.MainViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionsScreen(vm: MainViewModel) {
    val transactions by vm.monthTransactions.collectAsState()
    val categories   by vm.categories.collectAsState()
    val accounts     by vm.accounts.collectAsState()
    val monthYear    by vm.monthYear.collectAsState()

    var showAddSheet  by remember { mutableStateOf(false) }
    var searchQuery   by remember { mutableStateOf("") }
    var filterType    by remember { mutableStateOf("ALL") }

    val fmt      = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    val dateFmt  = SimpleDateFormat("dd MMM", Locale.getDefault())

    val filtered = transactions.filter { tx ->
        val matchSearch = searchQuery.isBlank() ||
            tx.merchant.contains(searchQuery, ignoreCase = true) ||
            tx.description.contains(searchQuery, ignoreCase = true)
        val matchType = filterType == "ALL" ||
            (filterType == "DEBIT"  && tx.type == TransactionType.DEBIT) ||
            (filterType == "CREDIT" && tx.type == TransactionType.CREDIT)
        matchSearch && matchType
    }

    Scaffold(
        containerColor = Black,
        floatingActionButton = {
            FloatingActionButton(
                onClick           = { showAddSheet = true },
                containerColor    = White,
                contentColor      = Black,
                shape             = RoundedCornerShape(4.dp)
            ) { Icon(Icons.Default.Add, "Add") }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Black)
        ) {
            // Header
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Black)
                        .padding(horizontal = 20.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("TRANSACTIONS", style = MaterialTheme.typography.headlineLarge, color = White)
                }
                NothingDivider()
            }

            // Search
            OutlinedTextField(
                value         = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder   = { Text("SEARCH...", style = MaterialTheme.typography.labelSmall, color = DimText) },
                modifier      = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                colors        = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor   = White,
                    unfocusedBorderColor = Border,
                    focusedTextColor     = White,
                    unfocusedTextColor   = White,
                    cursorColor          = White
                ),
                shape         = RoundedCornerShape(4.dp),
                textStyle     = MaterialTheme.typography.bodyMedium,
                singleLine    = true
            )

            // Filter chips
            Row(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("ALL", "DEBIT", "CREDIT").forEach { type ->
                    FilterChip(
                        selected = filterType == type,
                        onClick  = { filterType = type },
                        label    = { Text(type, style = MaterialTheme.typography.labelSmall) },
                        shape    = RoundedCornerShape(4.dp),
                        colors   = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = White,
                            selectedLabelColor     = Black,
                            labelColor             = DimText
                        )
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // List
            LazyColumn(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                items(filtered, key = { it.id }) { tx ->
                    var showDelete by remember { mutableStateOf(false) }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                            .combinedClickable(
                                onClick      = {},
                                onLongClick  = { showDelete = true }
                            ),
                        shape  = RoundedCornerShape(0.dp),
                        colors = CardDefaults.cardColors(containerColor = Surface1),
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (tx.type == TransactionType.CREDIT) Color(0xFF1A3A1A) else Border
                        )
                    ) {
                        // Left colored bar
                        Row(Modifier.height(IntrinsicSize.Min)) {
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .fillMaxHeight()
                                    .background(
                                        if (tx.type == TransactionType.CREDIT) GreenAccent
                                        else if (tx.isTransfer) DimText
                                        else NothingRed
                                    )
                            )
                            Column(Modifier.padding(12.dp).weight(1f)) {
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            text  = tx.merchant.ifBlank { "Manual Entry" }.uppercase(),
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = White
                                        )
                                        Text(
                                            text  = "${vm.categoryIcon(tx.categoryId)} ${vm.categoryName(tx.categoryId)} · ${vm.accountName(tx.accountId)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = DimText
                                        )
                                        if (tx.isTransfer) {
                                            Text("TRANSFER", style = MaterialTheme.typography.labelSmall, color = DimText)
                                        }
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text  = "${if (tx.type == TransactionType.CREDIT) "+" else "−"}${fmt.format(tx.amount)}",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = if (tx.type == TransactionType.CREDIT) GreenAccent else White
                                        )
                                        Text(
                                            dateFmt.format(Date(tx.date)),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = DimText
                                        )
                                    }
                                }
                                if (tx.source == TransactionSource.SMS || tx.source == TransactionSource.NOTIFICATION) {
                                    Text(
                                        "● AUTO-CAPTURED",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                        color = GreenAccent
                                    )
                                }
                            }
                        }
                    }

                    if (showDelete) {
                        AlertDialog(
                            onDismissRequest = { showDelete = false },
                            title            = { Text("DELETE?", style = MaterialTheme.typography.bodyMedium) },
                            text             = { Text("Remove this transaction?", style = MaterialTheme.typography.bodyMedium) },
                            confirmButton    = {
                                TextButton(onClick = { vm.deleteTransaction(tx); showDelete = false }) {
                                    Text("DELETE", color = NothingRed)
                                }
                            },
                            dismissButton    = {
                                TextButton(onClick = { showDelete = false }) { Text("CANCEL") }
                            },
                            containerColor   = Surface1
                        )
                    }
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    if (showAddSheet) {
        AddTransactionSheet(
            vm         = vm,
            accounts   = accounts,
            categories = categories,
            onDismiss  = { showAddSheet = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionSheet(
    vm: MainViewModel,
    accounts: List<Account>,
    categories: List<Category>,
    onDismiss: () -> Unit
) {
    var amount      by remember { mutableStateOf("") }
    var merchant    by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedAcc by remember { mutableStateOf(accounts.firstOrNull()) }
    var selectedCat by remember { mutableStateOf(categories.firstOrNull()) }
    var txType      by remember { mutableStateOf(TransactionType.DEBIT) }
    var isTransfer  by remember { mutableStateOf(false) }
    var toAccount   by remember { mutableStateOf<Account?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor   = Surface1,
        shape            = RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("ADD TRANSACTION",
                style = MaterialTheme.typography.headlineMedium.copy(letterSpacing = 3.sp),
                color = White)
            Spacer(Modifier.height(16.dp))

            // Type selector
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(TransactionType.DEBIT, TransactionType.CREDIT).forEach { type ->
                    FilterChip(
                        selected = txType == type && !isTransfer,
                        onClick  = { txType = type; isTransfer = false },
                        label    = { Text(type.name, style = MaterialTheme.typography.labelSmall) },
                        shape    = RoundedCornerShape(0.dp),
                        colors   = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = if (type == TransactionType.DEBIT) NothingRed else GreenAccent,
                            selectedLabelColor     = Black,
                            labelColor             = DimText
                        )
                    )
                }
                FilterChip(
                    selected = isTransfer,
                    onClick  = { isTransfer = true },
                    label    = { Text("TRANSFER", style = MaterialTheme.typography.labelSmall) },
                    shape    = RoundedCornerShape(0.dp),
                    colors   = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Border,
                        selectedLabelColor     = White,
                        labelColor             = DimText
                    )
                )
            }

            Spacer(Modifier.height(12.dp))
            MonoTextField("AMOUNT (₹)", amount) { amount = it }
            Spacer(Modifier.height(8.dp))
            MonoTextField("MERCHANT / PAYEE", merchant) { merchant = it }
            Spacer(Modifier.height(8.dp))
            MonoTextField("NOTES", description) { description = it }
            Spacer(Modifier.height(12.dp))

            // Account dropdown
            Text("ACCOUNT", style = MaterialTheme.typography.labelSmall, color = DimText)
            Spacer(Modifier.height(4.dp))
            var accExpanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = accExpanded, onExpandedChange = { accExpanded = it }) {
                OutlinedTextField(
                    value         = selectedAcc?.name?.uppercase() ?: "SELECT",
                    onValueChange = {},
                    readOnly      = true,
                    modifier      = Modifier.fillMaxWidth().menuAnchor(),
                    colors        = monoTextFieldColors(),
                    shape         = RoundedCornerShape(0.dp),
                    textStyle     = MaterialTheme.typography.bodyMedium
                )
                ExposedDropdownMenu(expanded = accExpanded, onDismissRequest = { accExpanded = false },
                    modifier = Modifier.background(Surface2)) {
                    accounts.forEach { acc ->
                        DropdownMenuItem(
                            text    = { Text(acc.name.uppercase(), style = MaterialTheme.typography.bodyMedium, color = White) },
                            onClick = { selectedAcc = acc; accExpanded = false }
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            if (isTransfer) {
                Text("TO ACCOUNT", style = MaterialTheme.typography.labelSmall, color = DimText)
                Spacer(Modifier.height(4.dp))
                var toExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = toExpanded, onExpandedChange = { toExpanded = it }) {
                    OutlinedTextField(
                        value         = toAccount?.name?.uppercase() ?: "SELECT",
                        onValueChange = {},
                        readOnly      = true,
                        modifier      = Modifier.fillMaxWidth().menuAnchor(),
                        colors        = monoTextFieldColors(),
                        shape         = RoundedCornerShape(0.dp),
                        textStyle     = MaterialTheme.typography.bodyMedium
                    )
                    ExposedDropdownMenu(expanded = toExpanded, onDismissRequest = { toExpanded = false },
                        modifier = Modifier.background(Surface2)) {
                        accounts.filter { it.id != selectedAcc?.id }.forEach { acc ->
                            DropdownMenuItem(
                                text    = { Text(acc.name.uppercase(), style = MaterialTheme.typography.bodyMedium, color = White) },
                                onClick = { toAccount = acc; toExpanded = false }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            // Category
            if (!isTransfer) {
                Text("CATEGORY", style = MaterialTheme.typography.labelSmall, color = DimText)
                Spacer(Modifier.height(4.dp))
                var catExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = it }) {
                    OutlinedTextField(
                        value         = "${selectedCat?.icon ?: ""} ${selectedCat?.name?.uppercase() ?: "SELECT"}",
                        onValueChange = {},
                        readOnly      = true,
                        modifier      = Modifier.fillMaxWidth().menuAnchor(),
                        colors        = monoTextFieldColors(),
                        shape         = RoundedCornerShape(0.dp),
                        textStyle     = MaterialTheme.typography.bodyMedium
                    )
                    ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false },
                        modifier = Modifier.background(Surface2)) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text    = { Text("${cat.icon} ${cat.name.uppercase()}", style = MaterialTheme.typography.bodyMedium, color = White) },
                                onClick = { selectedCat = cat; catExpanded = false }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            Button(
                onClick = {
                    val amt = amount.toDoubleOrNull() ?: return@Button
                    vm.addTransaction(Transaction(
                        amount      = amt,
                        type        = if (isTransfer) TransactionType.TRANSFER else txType,
                        accountId   = selectedAcc?.id,
                        toAccountId = if (isTransfer) toAccount?.id else null,
                        categoryId  = selectedCat?.id,
                        merchant    = merchant,
                        description = description,
                        isTransfer  = isTransfer,
                        source      = TransactionSource.MANUAL
                    ))
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(0.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black)
            ) {
                Text("SAVE TRANSACTION", style = MaterialTheme.typography.labelSmall.copy(fontSize = 13.sp))
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
fun MonoTextField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value         = value,
        onValueChange = onChange,
        label         = { Text(label, style = MaterialTheme.typography.labelSmall) },
        modifier      = Modifier.fillMaxWidth(),
        colors        = monoTextFieldColors(),
        shape         = RoundedCornerShape(0.dp),
        textStyle     = MaterialTheme.typography.bodyMedium,
        singleLine    = true
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun monoTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor   = White,
    unfocusedBorderColor = Border,
    focusedTextColor     = White,
    unfocusedTextColor   = White,
    focusedLabelColor    = DimText,
    unfocusedLabelColor  = DimText,
    cursorColor          = White
)
