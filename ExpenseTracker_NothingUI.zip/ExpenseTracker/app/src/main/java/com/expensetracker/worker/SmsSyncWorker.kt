package com.expensetracker.worker

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.expensetracker.BuildConfig
import com.expensetracker.data.AppDatabase
import com.expensetracker.sms.SmsParser
import com.expensetracker.sms.SmsReceiver

/**
 * Reads the SMS inbox to catch bank messages that arrived before the app was
 * installed or while the BroadcastReceiver was off.
 *
 * FIX #8: Tracks the timestamp of the last successful sync so we only process
 * new messages on subsequent runs, preventing duplicate transactions.
 */
class SmsSyncWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    companion object {
        private const val PREFS_NAME      = "sms_sync_prefs"
        private const val KEY_LAST_SYNC   = "last_sync_timestamp_ms"
        // On very first run, look back 90 days to catch recent history
        private const val FIRST_RUN_LOOKBACK_MS = 90L * 24 * 60 * 60 * 1000
    }

    private fun prefs(): SharedPreferences =
        applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    override suspend fun doWork(): Result {
        val context = applicationContext
        val db      = AppDatabase.getInstance(context)

        val lastSync = prefs().getLong(KEY_LAST_SYNC, 0L)
        val since    = if (lastSync == 0L)
            System.currentTimeMillis() - FIRST_RUN_LOOKBACK_MS
        else
            lastSync

        // FIX #8: Filter by date — only fetch SMS newer than last sync
        val cursor = context.contentResolver.query(
            Uri.parse("content://sms/inbox"),
            arrayOf("address", "body", "date"),
            "date > ?",                     // <-- date filter added
            arrayOf(since.toString()),
            "date DESC"
        ) ?: return Result.success()

        var processed = 0
        cursor.use {
            val addrIdx = it.getColumnIndex("address")
            val bodyIdx = it.getColumnIndex("body")
            while (it.moveToNext()) {
                val sender = it.getString(addrIdx) ?: continue
                val body   = it.getString(bodyIdx)  ?: continue
                val parsed = SmsParser.parse(body, sender) ?: continue
                SmsReceiver.processParsedSms(context, db, parsed, sender)
                processed++
            }
        }

        // Record successful sync time
        prefs().edit().putLong(KEY_LAST_SYNC, System.currentTimeMillis()).apply()

        if (BuildConfig.DEBUG) {
            Log.d("SmsSyncWorker", "Processed $processed new SMS messages since $since")
        }
        return Result.success()
    }
}
