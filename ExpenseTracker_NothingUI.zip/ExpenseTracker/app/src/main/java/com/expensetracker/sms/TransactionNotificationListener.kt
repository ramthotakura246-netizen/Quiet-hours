package com.expensetracker.sms

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.expensetracker.BuildConfig
import com.expensetracker.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class TransactionNotificationListener : NotificationListenerService() {

    // FIX #4: long-lived supervised scope tied to service lifetime
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val PAYMENT_APPS = setOf(
        "com.google.android.apps.nbu.paisa.user",  // Google Pay
        "com.phonepe.app",                           // PhonePe
        "net.one97.paytm",                           // Paytm
        "com.dreamplug.androidapp",                  // CRED
        "in.amazon.mShop.android.shopping",          // Amazon Pay
        "com.freecharge.android",                    // Freecharge
        "com.mobikwik_new",                          // MobiKwik
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg !in PAYMENT_APPS) return

        val extras  = sbn.notification.extras
        val title   = extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text    = extras.getString(Notification.EXTRA_TEXT)  ?: ""
        val bigText = extras.getString(Notification.EXTRA_BIG_TEXT) ?: text
        val body    = "$title $bigText"

        // FIX #12: never log notification content in release builds
        if (BuildConfig.DEBUG) {
            Log.d("NotifListener", "Payment app [$pkg]: ${body.take(40)}")
        }

        val parsed = SmsParser.parse(body, pkg) ?: return

        // FIX #4: use supervised service scope instead of a fire-and-forget bare scope
        serviceScope.launch {
            SmsReceiver.processParsedSms(
                applicationContext,
                AppDatabase.getInstance(applicationContext),
                parsed,
                pkg
            )
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel(null)
    }
}
