package com.expensetracker.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import com.expensetracker.BuildConfig
import com.expensetracker.data.AppDatabase
import com.expensetracker.data.entities.Transaction
import com.expensetracker.data.entities.TransactionSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.security.MessageDigest

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val db = AppDatabase.getInstance(context)

        // FIX #4: goAsync() keeps the process alive until coroutines complete
        val pendingResult = goAsync()
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

        scope.launch {
            try {
                messages.forEach { sms ->
                    val body   = sms.messageBody ?: return@forEach
                    val sender = sms.originatingAddress ?: ""

                    // FIX #12: sensitive SMS content only logged in debug builds
                    if (BuildConfig.DEBUG) {
                        Log.d("SmsReceiver", "SMS from $sender: ${body.take(40)}")
                    }

                    val parsed = SmsParser.parse(body, sender) ?: return@forEach
                    processParsedSms(context, db, parsed, sender)
                }
            } finally {
                pendingResult.finish()
                scope.cancel()
            }
        }
    }

    companion object {

        /**
         * FIX #9: Dedup key for transactions that have no UPI reference (card swipes,
         * ATM withdrawals). Hashes the stable fields so identical SMS retriggers
         * (e.g. SmsSyncWorker re-runs) don't create duplicates.
         */
        private fun fingerprintHash(parsed: ParsedTransaction, sender: String): String {
            // Round date to nearest minute to tolerate slight timestamp drift
            val minuteTs = (System.currentTimeMillis() / 60_000) * 60_000
            val raw = "${parsed.amount}|${parsed.type}|${parsed.accountHint}|${sender}|${minuteTs}"
            val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
            return digest.joinToString("") { "%02x".format(it) }
        }

        suspend fun processParsedSms(
            context: Context,
            db: AppDatabase,
            parsed: ParsedTransaction,
            sender: String
        ) {
            // FIX #9: Dedup — use UPI ref when available, else a fingerprint hash
            val dedupKey = parsed.reference.ifBlank { fingerprintHash(parsed, sender) }
            val existing = db.transactionDao().findByReference(dedupKey)
            if (existing != null) {
                if (BuildConfig.DEBUG) Log.d("SmsReceiver", "Duplicate, skipping: $dedupKey")
                return
            }

            // FIX #11: Properly collect the Flow to get the account list
            val accounts = db.accountDao().getAllAccounts().first()
            var accountId: Int? = null

            // Match account by bank code + last-4 hint
            if (parsed.accountHint.isNotBlank()) {
                accountId = accounts.firstOrNull { acc ->
                    acc.bankCode.equals(parsed.bankCode, ignoreCase = true) &&
                    acc.cardLastFour == parsed.accountHint
                }?.id
            }
            // Fallback: match by bank code only
            if (accountId == null && parsed.bankCode != "UNKNOWN") {
                accountId = accounts.firstOrNull { acc ->
                    acc.bankCode.equals(parsed.bankCode, ignoreCase = true)
                }?.id
            }

            // Update account balance if the SMS contained one
            if (parsed.balanceAfter != null && accountId != null) {
                db.accountDao().updateBalance(accountId, parsed.balanceAfter)
            }

            // Auto-categorise
            val allCats = db.categoryDao().getAllCategories().first()
            val suggestedName = SmsParser.suggestCategory(parsed.merchant, parsed.bankCode)
            val categoryId = allCats.firstOrNull {
                it.name.equals(suggestedName, ignoreCase = true)
            }?.id

            // FIX #2: Do NOT store rawSms. Description holds only the safe merchant string.
            val transaction = Transaction(
                amount       = parsed.amount,
                type         = parsed.type,
                accountId    = accountId,
                categoryId   = categoryId,
                merchant     = parsed.merchant,
                description  = parsed.merchant.ifBlank { parsed.bankCode },
                source       = TransactionSource.SMS,
                rawSms       = "",          // never persist raw SMS content
                isTransfer   = parsed.isTransfer,
                balanceAfter = parsed.balanceAfter,
                reference    = dedupKey
            )

            db.transactionDao().insert(transaction)
            if (BuildConfig.DEBUG) {
                Log.d("SmsReceiver", "Saved: ${parsed.amount} ${parsed.type} (acc=$accountId)")
            }
        }
    }
}
