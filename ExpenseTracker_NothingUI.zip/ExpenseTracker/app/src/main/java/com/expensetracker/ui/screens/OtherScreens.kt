package com.expensetracker.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.expensetracker.data.entities.*
import com.expensetracker.ui.theme.*
import com.expensetracker.viewmodel.MainViewModel
import java.text.NumberFormat
import java.util.Locale

// ── Shared field component ─────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
fun monoTextFieldColors() = TextFieldDefaults.outlinedTextFieldColors(
    focusedBorderColor   = White,
    unfocusedBorderColor = Border,
    cursorColor          = White,
    focusedTextColor     = White,
    unfocusedTextColor   = OffWhite,
    focusedLabelColor    = DimText,
    unfocusedLabelColor  = DimText,
    containerColor       = Surface2
)

@Composable
fun MonoTextField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value         = value,
        onValueChange = onValueChange,
        label         = { Text(label, style = MaterialTheme.typography.labelMedium) },
        modifier      = Modifier.fillMaxWidth(),
        shape         = RoundedCornerShape(4.dp),
        colors        = monoTextFieldColors(),
        textStyle     = MaterialTheme.typography.bodyMedium,
        singleLine    = true
    )
}

// ── Screen header ──────────────────────────────────────────────────────────────

@Composable
fun ScreenHeader(title: String) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Black)
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, style = MaterialTheme.typography.headlineLarge, color = White)
        }
        NothingDivider()
    }
}

// ── ACCOUNTS SCREEN ────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsScreen(vm: MainViewModel) {
    val accounts by vm.accounts.collectAsState()
    var showAdd  by remember { mutableStateOf(false) }
    val fmt      = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    Scaffold(
        containerColor = Black,
        floatingActionButton = {
            FloatingActionButton(
                onClick        = { showAdd = true },
                containerColor = White,
                contentColor   = Black,
                shape          = RoundedCornerShape(4.dp)
            ) { Icon(Icons.Default.Add, "Add Account") }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Black)
        ) {
            ScreenHeader("ACCOUNTS")
            SectionLabel("${accounts.size} CONNECTED")

            LazyColumn {
                items(accounts) { acc ->
                    val accentColor = try {
                        Color(android.graphics.Color.parseColor(acc.color))
                    } catch (e: Exception) { GreenAccent }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Color swatch — 2dp left bar
                            Box(
                                modifier = Modifier
                                    .width(2.dp)
                                    .height(40.dp)
                                    .background(accentColor, RoundedCornerShape(1.dp))
                            )
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(
                                    acc.name,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = White
                                )
                                Spacer(Modifier.height(3.dp))
                                Row {
                                    Text(
                                        acc.type.name.replace("_", " "),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = DimText
                                    )
                                    if (acc.cardLastFour.isNotBlank()) {
                                        Text(
                                            "  ···· ${acc.cardLastFour}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = DimText
                                        )
                                    }
                                }
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                fmt.format(acc.balance),
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = GreenAccent
                            )
                            Spacer(Modifier.height(2.dp))
                            Text("BALANCE", style = MaterialTheme.typography.labelSmall, color = DimText)
                        }
                    }
                    NothingDivider()
                }
            }
        }
    }

    if (showAdd) AddAccountSheet(vm) { showAdd = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAccountSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    var name         by remember { mutableStateOf("") }
    var balance      by remember { mutableStateOf("") }
    var balanceError by remember { mutableStateOf(false) }
    var nameError    by remember { mutableStateOf(false) }
    var bankCode     by remember { mutableStateOf("") }
    var cardLastFour by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(AccountType.SAVINGS) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor   = Surface1,
        shape            = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("NEW ACCOUNT", style = MaterialTheme.typography.headlineMedium, color = White)
            NothingDivider()
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value         = name,
                onValueChange = { name = it; nameError = false },
                label         = { Text("Account name", style = MaterialTheme.typography.labelMedium) },
                modifier      = Modifier.fillMaxWidth(),
                shape         = RoundedCornerShape(4.dp),
                colors        = monoTextFieldColors(),
                textStyle     = MaterialTheme.typography.bodyMedium,
                singleLine    = true,
                isError       = nameError,
                supportingText = if (nameError) {{ Text("Name is required", color = NothingRed, style = MaterialTheme.typography.labelSmall) }} else null
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value         = balance,
                onValueChange = { balance = it; balanceError = false },
                label         = { Text("Opening balance", style = MaterialTheme.typography.labelMedium) },
                modifier      = Modifier.fillMaxWidth(),
                shape         = RoundedCornerShape(4.dp),
                colors        = monoTextFieldColors(),
                textStyle     = MaterialTheme.typography.bodyMedium,
                singleLine    = true,
                isError       = balanceError,
                supportingText = if (balanceError) {{ Text("Enter a valid number (e.g. 5000.00)", color = NothingRed, style = MaterialTheme.typography.labelSmall) }} else null
            )
            Spacer(Modifier.height(10.dp))
            MonoTextField("Bank code  (e.g. HDFC, SBI)", bankCode) { bankCode = it }
            Spacer(Modifier.height(10.dp))
            MonoTextField("Card last 4 digits (optional)", cardLastFour) { cardLastFour = it }
            Spacer(Modifier.height(16.dp))
            Text("TYPE", style = MaterialTheme.typography.labelMedium, color = DimText)
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AccountType.values().forEach { type ->
                    FilterChip(
                        selected = selectedType == type,
                        onClick  = { selectedType = type },
                        label    = { Text(type.name.replace("_", " "), style = MaterialTheme.typography.labelMedium) },
                        shape    = RoundedCornerShape(4.dp),
                        colors   = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = White,
                            selectedLabelColor     = Black,
                            labelColor             = MidText
                        )
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    nameError    = name.isBlank()
                    balanceError = balance.isNotBlank() && balance.toDoubleOrNull() == null
                    if (nameError || balanceError) return@Button
                    vm.addAccount(Account(
                        name         = name,
                        type         = selectedType,
                        balance      = balance.toDoubleOrNull() ?: 0.0,
                        bankCode     = bankCode.uppercase(),
                        cardLastFour = cardLastFour
                    ))
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(4.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black)
            ) {
                Text("SAVE ACCOUNT", style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}

// ── BUDGET SCREEN ──────────────────────────────────────────────────────────────

@Composable
fun BudgetScreen(vm: MainViewModel) {
    val budgets    by vm.budgets.collectAsState()
    val categories by vm.categories.collectAsState()
    val monthYear  by vm.monthYear.collectAsState()
    val fmt        = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    var showAdd    by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(Black)) {
        ScreenHeader("BUDGET")
        SectionLabel(MainViewModel.formatMonth(monthYear).uppercase())

        LazyColumn {
            items(budgets) { budget ->
                val catSpend by vm.categorySpend(budget.categoryId ?: -1).collectAsState(initial = null)
                val spent    = catSpend ?: 0.0
                val pct      = if (budget.limitAmount > 0) (spent / budget.limitAmount).coerceIn(0.0, 1.0) else 0.0
                val catName  = if (budget.categoryId == null) "Overall" else vm.categoryName(budget.categoryId)
                val catIcon  = if (budget.categoryId == null) "💰" else vm.categoryIcon(budget.categoryId)
                val isOver   = spent >= budget.limitAmount * budget.alertAt

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "$catIcon  $catName",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = White
                        )
                        Text(
                            "${fmt.format(spent)} / ${fmt.format(budget.limitAmount)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isOver) NothingRed else MidText
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    // Thin progress bar
                    Box(
                        modifier = Modifier.fillMaxWidth().height(2.dp)
                            .background(BorderBright, RoundedCornerShape(1.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(pct.toFloat())
                                .fillMaxHeight()
                                .background(
                                    if (isOver) NothingRed else GreenAccent,
                                    RoundedCornerShape(1.dp)
                                )
                        )
                    }
                    if (isOver) {
                        Spacer(Modifier.height(5.dp))
                        Text(
                            "⚠  LIMIT EXCEEDED — ${(pct * 100).toInt()}% USED",
                            style = MaterialTheme.typography.labelSmall,
                            color = NothingRed
                        )
                    }
                }
                NothingDivider()
            }
            item {
                TextButton(
                    onClick  = { showAdd = true },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp)
                ) {
                    Text("+ ADD BUDGET", style = MaterialTheme.typography.labelLarge, color = DimText)
                }
                Spacer(Modifier.height(80.dp))
            }
        }
    }

    if (showAdd) AddBudgetSheet(vm, categories, monthYear) { showAdd = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddBudgetSheet(vm: MainViewModel, categories: List<Category>, monthYear: String, onDismiss: () -> Unit) {
    var limit       by remember { mutableStateOf("") }
    var limitError  by remember { mutableStateOf(false) }
    var selectedCat by remember { mutableStateOf<Category?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor   = Surface1,
        shape            = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(24.dp)) {
            Text("NEW BUDGET", style = MaterialTheme.typography.headlineMedium, color = White)
            NothingDivider()
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value         = limit,
                onValueChange = { limit = it; limitError = false },
                label         = { Text("Limit amount (₹)", style = MaterialTheme.typography.labelMedium) },
                modifier      = Modifier.fillMaxWidth(),
                shape         = RoundedCornerShape(4.dp),
                colors        = monoTextFieldColors(),
                textStyle     = MaterialTheme.typography.bodyMedium,
                singleLine    = true,
                isError       = limitError,
                supportingText = if (limitError) {{ Text("Enter a valid amount (e.g. 10000)", color = NothingRed, style = MaterialTheme.typography.labelSmall) }} else null
            )
            Spacer(Modifier.height(16.dp))
            Text("CATEGORY", style = MaterialTheme.typography.labelMedium, color = DimText)
            Spacer(Modifier.height(8.dp))
            var catExpanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = it }) {
                OutlinedTextField(
                    value         = selectedCat?.let { "${it.icon} ${it.name}" } ?: "OVERALL",
                    onValueChange = {}, readOnly = true,
                    modifier      = Modifier.fillMaxWidth().menuAnchor(),
                    colors        = monoTextFieldColors(),
                    shape         = RoundedCornerShape(4.dp),
                    textStyle     = MaterialTheme.typography.bodyMedium
                )
                ExposedDropdownMenu(
                    expanded          = catExpanded,
                    onDismissRequest  = { catExpanded = false },
                    modifier          = Modifier.background(Surface2)
                ) {
                    DropdownMenuItem(
                        text    = { Text("OVERALL", style = MaterialTheme.typography.bodyMedium, color = White) },
                        onClick = { selectedCat = null; catExpanded = false }
                    )
                    categories.forEach { cat ->
                        DropdownMenuItem(
                            text    = { Text("${cat.icon}  ${cat.name}", style = MaterialTheme.typography.bodyMedium, color = White) },
                            onClick = { selectedCat = cat; catExpanded = false }
                        )
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    val amt = limit.toDoubleOrNull()
                    if (amt == null || amt <= 0) { limitError = true; return@Button }
                    vm.addBudget(Budget(categoryId = selectedCat?.id, monthYear = monthYear, limitAmount = amt))
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(4.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black)
            ) {
                Text("SAVE BUDGET", style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}

// ── REPORTS SCREEN ─────────────────────────────────────────────────────────────

@Composable
fun ReportsScreen(vm: MainViewModel) {
    val transactions by vm.monthTransactions.collectAsState()
    val categories   by vm.categories.collectAsState()
    val monthYear    by vm.monthYear.collectAsState()
    val fmt          = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    val catTotals = transactions
        .filter { !it.isTransfer && it.type == TransactionType.DEBIT }
        .groupBy { it.categoryId }
        .mapValues { (_, txs) -> txs.sumOf { it.amount } }
        .entries.sortedByDescending { it.value }

    val grandTotal = catTotals.sumOf { it.value }.let { if (it == 0.0) 1.0 else it }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black)
            .verticalScroll(rememberScrollState())
    ) {
        ScreenHeader("REPORTS")
        SectionLabel(MainViewModel.formatMonth(monthYear).uppercase() + "  ·  CATEGORY BREAKDOWN")

        catTotals.forEachIndexed { index, (catId, amount) ->
            val cat    = categories.find { it.id == catId }
            val pct    = (amount / grandTotal * 100).toInt()
            val accent = try {
                Color(android.graphics.Color.parseColor(cat?.color ?: "#555"))
            } catch (e: Exception) { DimText }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Rank number
                Text(
                    text  = "${index + 1}",
                    style = MaterialTheme.typography.labelLarge,
                    color = DimText,
                    modifier = Modifier.width(20.dp)
                )
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${cat?.icon ?: "📂"}  ${(cat?.name ?: "Unknown")}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = White
                        )
                        Text(fmt.format(amount), style = MaterialTheme.typography.bodyMedium, color = White)
                    }
                    Spacer(Modifier.height(8.dp))
                    Box(
                        modifier = Modifier.fillMaxWidth().height(2.dp)
                            .background(BorderBright, RoundedCornerShape(1.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(pct / 100f)
                                .fillMaxHeight()
                                .background(accent, RoundedCornerShape(1.dp))
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("$pct% of spend", style = MaterialTheme.typography.labelSmall, color = DimText)
                }
            }
            NothingDivider()
        }
        Spacer(Modifier.height(80.dp))
    }
}
